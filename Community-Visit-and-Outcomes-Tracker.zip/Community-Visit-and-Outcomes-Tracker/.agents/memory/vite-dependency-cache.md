---
name: Vite dependency cache after runtime upgrades
description: Installed React versions and the browser's optimized renderer can differ after a patch upgrade.
---

Treat the browser's optimized dependency versions as separate from the versions installed on disk after React upgrades.

**Why:** In this environment, upgrading React and React DOM together left Vite serving the previous renderer even after an ordinary workflow restart. Matching package versions did not prove matching browser runtime versions.

**How to apply:** When runtime version errors contradict installed versions, invalidate the affected app's optimized dependency cache rather than changing already-matching dependency versions again.
