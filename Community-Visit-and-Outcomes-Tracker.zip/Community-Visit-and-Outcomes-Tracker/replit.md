# Mercy Holisitic Connect

A web app for a nonprofit serving people experiencing homelessness: record each guest's arrival, departure, service, and notes, then export aggregate reports for stakeholders.

## Run & Operate

- `pnpm --filter @workspace/api-server run dev` — run the API server (port 5000)
- `pnpm run typecheck` — full typecheck across all packages
- `pnpm run build` — typecheck + build all packages
- `pnpm --filter @workspace/api-spec run codegen` — regenerate API hooks and Zod schemas from the OpenAPI spec
- `pnpm --filter @workspace/db run push` — push DB schema changes (dev only)
- Required env: `DATABASE_URL` — Postgres connection string

## Stack

- pnpm workspaces, Node.js 24, TypeScript 5.9
- API: Express 5
- DB: PostgreSQL + Drizzle ORM
- Validation: Zod (`zod/v4`), `drizzle-zod`
- API codegen: Orval (from OpenAPI spec)
- Build: esbuild (CJS bundle)

## Where things live

- `artifacts/community-visit-tracker/` — React staff portal, public homepage, and branded sign-in
- `lib/api-spec/openapi.yaml` — API contract; regenerate after every contract edit
- `lib/db/src/schema/` — guest and visit tables
- `artifacts/api-server/src/routes/visits.ts` — account-scoped guest and visit operations
- `artifacts/api-server/src/routes/reports.ts` — dashboard and aggregate reports

## Architecture decisions

- Each signed-in account owns a separate set of records. Do not introduce shared nonprofit/team access without explicit membership authorization.
- Use generated guest codes rather than collecting names or contact details by default. Descriptions and notes are sensitive and must not appear in stakeholder exports or logs.
- Guest handouts are distinct from aggregate stakeholder reports: they intentionally include the guest's code and visit history. Staff visit notes and outcomes are excluded. Descriptions are included only after staff explicitly opt in from the preview.
- Guest demographics are optional, self-reported selections, never inferred from names, appearance, accents, or old notes. Use age bands instead of dates of birth or exact ages to minimize identifying data. Existing text descriptions are preserved unless staff explicitly confirm removal or enable a previewed retention policy.
- Ethnicity replaces nationality on the intake form. Existing nationality answers remain separately labeled legacy responses; never relabel or infer them as ethnicity, because the concepts are different.
- Guest photos are optional, consent-based, and private to the owning account. Store only object paths/timestamps in PostgreSQL and bytes in App Storage; serve only through owner-checked API routes. Re-encode images to remove EXIF/GPS metadata. Photos are never printed on guest handouts or stakeholder reports.
- Guest QR codes encode only the existing guest code, locally generated without external QR services. They are lookup aids, not sign-in tokens or public record links. Include QR codes on handouts; decoding a QR image happens locally and searches only the signed-in account's guest directory.
- Do not seed operational guest/visit data: example records would contaminate stakeholder reports.
- Reporting periods use UTC arrival dates, inclusive of both selected days. Completed-visit duration averages exclude open visits.
- Support location records where a service was provided (center, outreach site, or community area), not a guest's live/home/sleeping location. Never infer or collect GPS/background movement data for this feature. Old visits remain Not recorded until explicitly updated.
- Support-site names appear in guest handouts and aggregate location reporting/CSV. Staff must use service sites rather than private addresses and review labels before sharing. CSV exports escape user-entered names against spreadsheet formula execution.
- Staff time is a separate, account-owned log. Clock-in/out timestamps come from the database; only one open shift is allowed per account. Date filters use the UTC clock-in date and count the entire duration of completed shifts, excluding open shifts.
- Privacy retention is account-owned and disabled by default. Aging starts at the last profile edit, with creation time as the fallback for older records. Enabling/changing the period requires a fresh, account-bound preview and confirmation; it removes eligible details immediately, then at startup and hourly while the server is running. Disabling prevents future automatic removal, not restoration. Retention and confirmed description removal never delete coded guests, visits, services, photos, or staff shifts.
- Preview tokens expire after ten minutes or on server restart and are rejected if affected profiles or settings change. Profile writers and retention lock the same account settings row to prevent a queued worker from overriding a disable.
- This tool does not claim compliance with a specific state reporting standard, HMIS, HIPAA, or a nonprofit's retention policies.

## Product

- Create a coded guest record and find it again for repeat visits.
- Save, edit, or clear guest profile buttons for race, gender, sex, ethnicity, languages, and age range. Race/language allow multiple responses; all fields can be skipped or declined. Earlier text descriptions and nationality responses remain readable. Guest profile details are excluded from stakeholder reports and from handouts unless explicitly selected.
- Add, replace, or remove a private guest photo (JPG/PNG/WebP, up to 5 MB), download each guest's QR code, or find a guest by scanning a QR image.
- Record or edit a support location on each visit, reuse previous site names, view locations in visit history and guest summaries, and review visit totals by support location in reports.
- Preview a guest-specific visit/service handout and print it or save it as PDF.
- Record arrivals, departures, service categories, optional outcomes, and editable visit notes.
- Review current on-site guests and historical visits.
- Generate date-range aggregate reports and download CSV or print.
- Sign-in uses Clerk; all operational API endpoints require a session and enforce account ownership.
- Staff can clock themselves in and out under **Staff time**, view saved shifts, and review completed hours for a chosen date range. This is a personal time log, not shared staff administration or payroll.

## User preferences

The user named the app **Mercy Holisitic Connect**. Preserve that exact spelling.

The user requested tracking each person's visits and departures with notes for stakeholder reports. They also confirmed they want both a saved guest description and a printable visit/services summary to give the guest when they return. They requested staff time in and time out as well.
The user later requested replacing the guest-description text entry with buttons for race, gender, sex, nationality, language, and age.
The user then requested ethnicity instead of nationality, a space for each guest's photo, and a QR code per guest.
The user requested location tracking for where guests were supported.

## Gotchas

- Clerk development and production users are separate. Browser API auth uses session cookies, not manually attached tokens.
- The generated date-query schemas require `Date` values; validate ISO calendar strings before converting query parameters.
- Do not log raw database errors or request bodies: they can include visit notes.

## Pointers

- See the `pnpm-workspace` skill for workspace structure, TypeScript setup, and package details
