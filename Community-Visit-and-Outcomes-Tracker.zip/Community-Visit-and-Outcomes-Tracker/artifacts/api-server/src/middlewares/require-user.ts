import { getAuth } from "@clerk/express";
import type { RequestHandler } from "express";

export const requireUser: RequestHandler = (req, res, next) => {
  const { userId } = getAuth(req);
  if (!userId) {
    res.status(401).json({ error: "Sign in to access your records." });
    return;
  }
  res.locals.userId = userId;
  res.setHeader("Cache-Control", "private, no-store");
  next();
};
