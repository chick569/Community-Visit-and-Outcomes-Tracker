import { createHash, createHmac, randomBytes, timingSafeEqual } from "node:crypto";
import { and, eq, isNotNull, lt, or, sql } from "drizzle-orm";
import { db, clientsTable, privacySettingsTable } from "@workspace/db";
import { logger } from "./logger";

type Transaction = Parameters<Parameters<typeof db.transaction>[0]>[0];
// A restart invalidates outstanding previews rather than accepting stale consent.
const previewKey = randomBytes(32);
const dayMs = 86_400_000;
export const retentionCutoff = (days: number, now = new Date()) => new Date(now.getTime() - days * dayMs);

export function hasDemographics(value: Record<string, unknown>): boolean {
  return Object.values(value).some((v) => Array.isArray(v) ? v.length > 0 : v !== null && v !== undefined && v !== "");
}

/** All profile writers and retention workers take this lock, serializing account changes. */
export async function lockPrivacy(tx: Transaction, ownerId: string) {
  await tx.insert(privacySettingsTable).values({ ownerId }).onConflictDoNothing();
  const [settings] = await tx.select().from(privacySettingsTable)
    .where(eq(privacySettingsTable.ownerId, ownerId)).for("update");
  return settings;
}

export async function affectedProfiles(tx: Transaction, ownerId: string, cutoff: Date) {
  const rows = await tx.select({
    id: clientsTable.id, code: clientsTable.code,
    description: clientsTable.description, demographics: clientsTable.demographics,
    editedAt: sql<Date>`coalesce(${clientsTable.sensitiveUpdatedAt}, ${clientsTable.createdAt})`,
  }).from(clientsTable).where(and(
    eq(clientsTable.ownerId, ownerId),
    lt(sql`coalesce(${clientsTable.sensitiveUpdatedAt}, ${clientsTable.createdAt})`, cutoff),
    or(isNotNull(clientsTable.description), sql`${clientsTable.demographics} <> '{}'::jsonb`),
  )).orderBy(clientsTable.id);
  return rows.filter((r) => Boolean(r.description) || hasDemographics(r.demographics));
}

type Affected = Awaited<ReturnType<typeof affectedProfiles>>;
function fingerprint(rows: Affected) {
  // No field values are included in the token or in logs.
  return createHash("sha256").update(JSON.stringify(rows.map((r) => [r.id, r.editedAt]))).digest("hex");
}

export function issuePreview(ownerId: string, days: number, cutoff: Date, rows: Affected, settingsAt: Date) {
  const expiresAt = new Date(Date.now() + 10 * 60_000);
  const payload = Buffer.from(JSON.stringify({
    ownerId, days, cutoff: cutoff.toISOString(), expiresAt: expiresAt.toISOString(),
    fingerprint: fingerprint(rows), settingsAt: settingsAt.toISOString(),
  })).toString("base64url");
  const signature = createHmac("sha256", previewKey).update(payload).digest("base64url");
  return { previewToken: `${payload}.${signature}`, expiresAt, cutoff,
    records: rows.map((r) => ({ code: r.code, hasDescription: Boolean(r.description), hasDemographics: hasDemographics(r.demographics) })) };
}

export function readPreview(token: string, ownerId: string, days: number, settingsAt: Date) {
  try {
    const [payload, signature, extra] = token.split(".");
    if (!payload || !signature || extra) return null;
    const expected = createHmac("sha256", previewKey).update(payload).digest();
    const supplied = Buffer.from(signature, "base64url");
    if (supplied.length !== expected.length || !timingSafeEqual(supplied, expected)) return null;
    const data = JSON.parse(Buffer.from(payload, "base64url").toString());
    if (data.ownerId !== ownerId || data.days !== days || data.settingsAt !== settingsAt.toISOString() ||
      new Date(data.expiresAt).getTime() <= Date.now()) return null;
    return { cutoff: new Date(data.cutoff), fingerprint: data.fingerprint as string };
  } catch { return null; }
}

export const matchesPreview = (rows: Affected, expected: string) => fingerprint(rows) === expected;

export async function clearExpiredProfiles(tx: Transaction, ownerId: string, cutoff: Date) {
  // UPDATE, never DELETE: operational records and their foreign keys remain untouched.
  await tx.update(clientsTable).set({ demographics: {}, description: null })
    .where(and(eq(clientsTable.ownerId, ownerId),
      lt(sql`coalesce(${clientsTable.sensitiveUpdatedAt}, ${clientsTable.createdAt})`, cutoff)));
}

export async function runRetention(now = new Date()) {
  const enabled = await db.select({ ownerId: privacySettingsTable.ownerId }).from(privacySettingsTable)
    .where(isNotNull(privacySettingsTable.retentionDays));
  for (const { ownerId } of enabled) {
    await runAccountRetention(ownerId, now);
  }
}

export async function runAccountRetention(ownerId: string, now = new Date()) {
  await db.transaction(async (tx) => {
    const settings = await lockPrivacy(tx, ownerId);
    // Re-read under lock: disabling must win over a previously queued worker.
    if (settings.retentionDays === null) return;
    await clearExpiredProfiles(tx, ownerId, retentionCutoff(settings.retentionDays, now));
  });
}

export function startRetentionWorker() {
  let running = false;
  const tick = async () => {
    if (running) return;
    running = true;
    try { await runRetention(); }
    catch { logger.error("Privacy retention failed; it will retry on the next hourly run"); }
    finally { running = false; }
  };
  void tick();
  const timer = setInterval(() => void tick(), 60 * 60_000);
  timer.unref();
}
