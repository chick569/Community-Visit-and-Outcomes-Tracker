import { clientsTable, visitsTable } from "@workspace/db";
import { getTableColumns } from "drizzle-orm";

export const visitColumns = {
  ...getTableColumns(visitsTable),
  clientCode: clientsTable.code,
};

export function withStatus<T extends { departedAt: Date | null }>(visit: T) {
  return { ...visit, status: visit.departedAt ? "completed" as const : "on-site" as const };
}

/** Convert only real ISO calendar dates before generated date-schema validation. */
export function dateQuery(query: Record<string, unknown>) {
  const result = { ...query };
  for (const key of ["dateFrom", "dateTo"]) {
    const value = result[key];
    if (typeof value === "string" && /^\d{4}-\d{2}-\d{2}$/.test(value)) {
      const date = new Date(`${value}T00:00:00.000Z`);
      if (!Number.isNaN(date.getTime()) && date.toISOString().slice(0, 10) === value) {
        result[key] = date;
      }
    }
  }
  return result;
}

export const nextDay = (date: Date) => new Date(date.getTime() + 86_400_000);
