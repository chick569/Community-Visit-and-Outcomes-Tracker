import { Router, type IRouter } from "express";
import { and, desc, eq, gte, lt, sql } from "drizzle-orm";
import { db, clientsTable, visitsTable } from "@workspace/db";
import { GetDashboardResponse, GetReportQueryParams, GetReportResponse } from "@workspace/api-zod";
import { requireUser } from "../middlewares/require-user";
import { dateQuery, nextDay, visitColumns, withStatus } from "../lib/visit-data";

const router: IRouter = Router();
router.use(requireUser);
const services = ["shelter", "meals", "hygiene", "case-management", "outreach", "other"];

router.get("/dashboard", async (_req, res): Promise<void> => {
  const now = new Date();
  const today = new Date(Date.UTC(now.getUTCFullYear(), now.getUTCMonth(), now.getUTCDate()));
  const tomorrow = nextDay(today);
  const month = new Date(Date.UTC(now.getUTCFullYear(), now.getUTCMonth(), 1));
  const owner = eq(visitsTable.ownerId, res.locals.userId);
  const [stats, serviceRows, recent] = await Promise.all([
    db.select({
      todayVisits: sql<number>`count(*) filter (where ${visitsTable.arrivedAt} >= ${today} and ${visitsTable.arrivedAt} < ${tomorrow})::int`,
      currentlyOnSite: sql<number>`count(*) filter (where ${visitsTable.departedAt} is null)::int`,
      departuresToday: sql<number>`count(*) filter (where ${visitsTable.departedAt} >= ${today} and ${visitsTable.departedAt} < ${tomorrow})::int`,
      uniquePeopleToday: sql<number>`count(distinct ${visitsTable.clientId}) filter (where ${visitsTable.arrivedAt} >= ${today} and ${visitsTable.arrivedAt} < ${tomorrow})::int`,
      monthVisits: sql<number>`count(*) filter (where ${visitsTable.arrivedAt} >= ${month})::int`,
    }).from(visitsTable).where(owner),
    db.select({ service: visitsTable.service, visits: sql<number>`count(*)::int` })
      .from(visitsTable).where(and(owner, gte(visitsTable.arrivedAt, month))).groupBy(visitsTable.service),
    db.select(visitColumns).from(visitsTable)
      .innerJoin(clientsTable, eq(visitsTable.clientId, clientsTable.id))
      .where(and(owner, eq(clientsTable.ownerId, res.locals.userId)))
      .orderBy(desc(visitsTable.arrivedAt)).limit(6),
  ]);
  res.json(GetDashboardResponse.parse({
    ...stats[0],
    serviceBreakdown: services.map((service) => ({ service, visits: serviceRows.find((row) => row.service === service)?.visits ?? 0 })),
    recentVisits: recent.map(withStatus),
  }));
});

router.get("/reports", async (req, res): Promise<void> => {
  const parsed = GetReportQueryParams.safeParse(dateQuery(req.query));
  if (!parsed.success) { res.status(400).json({ error: "Select valid start and end dates." }); return; }
  const { dateFrom, dateTo } = parsed.data;
  const days = Math.round((dateTo.getTime() - dateFrom.getTime()) / 86_400_000) + 1;
  if (days < 1 || days > 3660) { res.status(400).json({ error: "Choose a date range of no more than ten years, with the start before the end." }); return; }
  const scope = and(
    eq(visitsTable.ownerId, res.locals.userId),
    gte(visitsTable.arrivedAt, dateFrom),
    lt(visitsTable.arrivedAt, nextDay(dateTo)),
  );
  const [stats, serviceRows, dailyRows, locationBreakdown] = await Promise.all([
    db.select({
      totalVisits: sql<number>`count(*)::int`,
      uniquePeople: sql<number>`count(distinct ${visitsTable.clientId})::int`,
      completedVisits: sql<number>`count(*) filter (where ${visitsTable.departedAt} is not null)::int`,
      openVisits: sql<number>`count(*) filter (where ${visitsTable.departedAt} is null)::int`,
      averageVisitHours: sql<number>`coalesce(avg(extract(epoch from (${visitsTable.departedAt} - ${visitsTable.arrivedAt})) / 3600) filter (where ${visitsTable.departedAt} is not null), 0)::float8`,
    }).from(visitsTable).where(scope),
    db.select({ service: visitsTable.service, visits: sql<number>`count(*)::int` })
      .from(visitsTable).where(scope).groupBy(visitsTable.service),
    db.select({
      date: sql<string>`to_char(${visitsTable.arrivedAt} AT TIME ZONE 'UTC', 'YYYY-MM-DD')`,
      visits: sql<number>`count(*)::int`,
      people: sql<number>`count(distinct ${visitsTable.clientId})::int`,
    }).from(visitsTable).where(scope)
      .groupBy(sql`to_char(${visitsTable.arrivedAt} AT TIME ZONE 'UTC', 'YYYY-MM-DD')`),
    db.select({ location: visitsTable.location, visits: sql<number>`count(*)::int` })
      .from(visitsTable).where(scope).groupBy(visitsTable.location).orderBy(desc(sql`count(*)`)),
  ]);
  const dailyBreakdown = Array.from({ length: days }, (_, i) => {
    const date = new Date(dateFrom.getTime() + i * 86_400_000);
    const matching = dailyRows.find((row) => row.date === date.toISOString().slice(0, 10));
    return { date, visits: matching?.visits ?? 0, people: matching?.people ?? 0 };
  });
  const report = GetReportResponse.parse({
    dateFrom, dateTo, ...stats[0],
    averageVisitHours: Math.round((stats[0]?.averageVisitHours ?? 0) * 100) / 100,
    serviceBreakdown: services.map((service) => ({ service, visits: serviceRows.find((row) => row.service === service)?.visits ?? 0 })),
    dailyBreakdown, locationBreakdown,
  });
  res.json({
    ...report,
    dateFrom: dateFrom.toISOString().slice(0, 10),
    dateTo: dateTo.toISOString().slice(0, 10),
    dailyBreakdown: report.dailyBreakdown.map((row) => ({ ...row, date: row.date.toISOString().slice(0, 10) })),
  });
});

export default router;
