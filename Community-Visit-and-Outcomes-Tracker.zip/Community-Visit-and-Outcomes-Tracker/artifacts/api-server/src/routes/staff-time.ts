import { Router, type IRouter } from "express";
import { and, desc, eq, gte, isNull, lt, sql } from "drizzle-orm";
import { db, staffShiftsTable } from "@workspace/db";
import {
  GetStaffTimeQueryParams, GetStaffTimeResponse,
  ClockInStaffResponse, ClockOutStaffParams, ClockOutStaffResponse,
} from "@workspace/api-zod";
import { requireUser } from "../middlewares/require-user";
import { dateQuery, nextDay } from "../lib/visit-data";

const router: IRouter = Router();
router.use(requireUser);

router.get("/staff-time", async (req, res): Promise<void> => {
  const parsed = GetStaffTimeQueryParams.safeParse(dateQuery(req.query));
  if (!parsed.success) { res.status(400).json({ error: "Select valid start and end dates." }); return; }
  const { dateFrom, dateTo } = parsed.data;
  if (dateFrom > dateTo || dateTo.getTime() - dateFrom.getTime() > 3660 * 86_400_000) {
    res.status(400).json({ error: "Choose a valid date range of no more than ten years." }); return;
  }
  const owner = eq(staffShiftsTable.ownerId, res.locals.userId);
  const [shifts, active] = await Promise.all([
    db.select().from(staffShiftsTable).where(and(
      owner, gte(staffShiftsTable.clockedInAt, dateFrom),
      lt(staffShiftsTable.clockedInAt, nextDay(dateTo)),
    )).orderBy(desc(staffShiftsTable.clockedInAt)),
    db.select().from(staffShiftsTable).where(and(owner, isNull(staffShiftsTable.clockedOutAt))).limit(1),
  ]);
  const completedHours = shifts.reduce((sum, shift) => sum + (
    shift.clockedOutAt ? (shift.clockedOutAt.getTime() - shift.clockedInAt.getTime()) / 3_600_000 : 0
  ), 0);
  res.json(GetStaffTimeResponse.parse({ shifts, currentShift: active[0] ?? null, completedHours }));
});

router.post("/staff-time/clock-in", async (_req, res): Promise<void> => {
  const [shift] = await db.insert(staffShiftsTable).values({ ownerId: res.locals.userId })
    .onConflictDoNothing().returning();
  if (!shift) { res.status(409).json({ error: "You are already clocked in. Clock out before starting another shift." }); return; }
  res.status(201).json(ClockInStaffResponse.parse(shift));
});

router.post("/staff-time/:shiftId/clock-out", async (req, res): Promise<void> => {
  const params = ClockOutStaffParams.safeParse(req.params);
  if (!params.success) { res.status(400).json({ error: "Invalid shift." }); return; }
  const ownedShift = and(eq(staffShiftsTable.id, params.data.shiftId), eq(staffShiftsTable.ownerId, res.locals.userId));
  const [shift] = await db.update(staffShiftsTable)
    .set({ clockedOutAt: sql`clock_timestamp()` })
    .where(and(ownedShift, isNull(staffShiftsTable.clockedOutAt))).returning();
  if (!shift) {
    const [existing] = await db.select({ id: staffShiftsTable.id }).from(staffShiftsTable).where(ownedShift);
    res.status(existing ? 409 : 404).json({ error: existing ? "This shift is already clocked out." : "Shift not found." }); return;
  }
  res.json(ClockOutStaffResponse.parse(shift));
});

export default router;
