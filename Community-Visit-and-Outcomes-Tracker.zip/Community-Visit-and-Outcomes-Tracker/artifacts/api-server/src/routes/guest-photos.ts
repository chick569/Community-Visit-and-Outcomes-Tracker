import { randomUUID } from "node:crypto";
import { Router, raw, type IRouter, type RequestHandler } from "express";
import sharp from "sharp";
import { and, eq } from "drizzle-orm";
import { clientsTable, db } from "@workspace/db";
import { GetGuestPhotoParams, UploadGuestPhotoResponse, DeleteGuestPhotoResponse } from "@workspace/api-zod";
import { requireUser } from "../middlewares/require-user";
import { ObjectStorageService, objectStorageClient } from "../lib/objectStorage";

const router: IRouter = Router();
router.use(requireUser);

function storedFile(path: string) {
  const [bucket, ...parts] = path.replace(/^\/+/, "").split("/");
  if (!bucket || !parts.length) throw new Error("Invalid private photo path");
  return objectStorageClient.bucket(bucket).file(parts.join("/"));
}

const loadGuest: RequestHandler = async (req, res, next) => {
  const parsed = GetGuestPhotoParams.safeParse(req.params);
  if (!parsed.success) { res.status(400).json({ error: "Invalid guest record." }); return; }
  const [guest] = await db.select().from(clientsTable).where(and(
    eq(clientsTable.id, parsed.data.clientId), eq(clientsTable.ownerId, res.locals.userId),
  )).limit(1);
  if (!guest) { res.status(404).json({ error: "Guest record not found." }); return; }
  res.locals.photoGuest = guest;
  next();
};

const photoBody = raw({ type: ["image/jpeg", "image/png", "image/webp"], limit: "5mb" });
const readPhoto: RequestHandler = (req, res, next) => photoBody(req, res, (error) => {
  if (error) { res.status(413).json({ error: "Choose a photo no larger than 5 MB." }); return; }
  next();
});

router.get("/clients/:clientId/photo", loadGuest, async (_req, res): Promise<void> => {
  const guest = res.locals.photoGuest as typeof clientsTable.$inferSelect;
  if (!guest.photoObjectPath) { res.status(404).json({ error: "No photo saved." }); return; }
  try {
    const [photo] = await storedFile(guest.photoObjectPath).download();
    res.setHeader("X-Content-Type-Options", "nosniff");
    res.type("image/jpeg").send(photo);
  } catch (error) {
    if ((error as { code?: number }).code === 404) {
      res.status(404).json({ error: "Photo file not found." }); return;
    }
    throw error;
  }
});

router.put("/clients/:clientId/photo", loadGuest, readPhoto, async (req, res): Promise<void> => {
  if (!Buffer.isBuffer(req.body) || !req.body.length) {
    res.status(400).json({ error: "Choose a JPG, PNG, or WebP photo." }); return;
  }
  let jpeg: Buffer;
  try {
    const image = sharp(req.body, { limitInputPixels: 20_000_000 });
    const info = await image.metadata();
    if (!info.format || !["jpeg", "png", "webp"].includes(info.format) || (info.pages ?? 1) > 1) {
      res.status(400).json({ error: "Choose a still JPG, PNG, or WebP photo." }); return;
    }
    // Re-encoding strips EXIF/GPS metadata; no face recognition or demographic inference.
    jpeg = await image.rotate().resize({ width: 1024, height: 1024, fit: "inside", withoutEnlargement: true })
      .jpeg({ quality: 85 }).toBuffer();
  } catch {
    res.status(400).json({ error: "Use a valid JPG, PNG, or WebP photo up to 20 megapixels." }); return;
  }
  const guest = res.locals.photoGuest as typeof clientsTable.$inferSelect;
  const updated = await db.transaction(async (tx) => {
    const scope = and(eq(clientsTable.id, guest.id), eq(clientsTable.ownerId, res.locals.userId));
    const [current] = await tx.select().from(clientsTable).where(scope).for("update");
    if (!current) return null;
    const path = current.photoObjectPath ?? `${new ObjectStorageService().getPrivateObjectDir().replace(/\/$/, "")}/guest-photos/${randomUUID()}.jpg`;
    const file = storedFile(path);
    await file.save(jpeg, { resumable: false, metadata: { contentType: "image/jpeg", cacheControl: "private, no-store" } });
    try {
      const [saved] = await tx.update(clientsTable).set({ photoObjectPath: path, photoUpdatedAt: new Date() })
        .where(scope).returning({ photoUpdatedAt: clientsTable.photoUpdatedAt });
      return saved;
    } catch (error) {
      if (!current.photoObjectPath) await file.delete({ ignoreNotFound: true });
      throw error;
    }
  });
  if (!updated) { res.status(404).json({ error: "Guest record not found." }); return; }
  res.json(UploadGuestPhotoResponse.parse(updated));
});

router.delete("/clients/:clientId/photo", loadGuest, async (_req, res): Promise<void> => {
  const guest = res.locals.photoGuest as typeof clientsTable.$inferSelect;
  const updated = await db.transaction(async (tx) => {
    const scope = and(eq(clientsTable.id, guest.id), eq(clientsTable.ownerId, res.locals.userId));
    const [current] = await tx.select().from(clientsTable).where(scope).for("update");
    if (!current) return null;
    // Delete storage bytes before clearing the reference; a failed delete is retryable.
    if (current.photoObjectPath) await storedFile(current.photoObjectPath).delete({ ignoreNotFound: true });
    const [saved] = await tx.update(clientsTable).set({ photoObjectPath: null, photoUpdatedAt: null })
      .where(scope).returning({ photoUpdatedAt: clientsTable.photoUpdatedAt });
    return saved;
  });
  if (!updated) { res.status(404).json({ error: "Guest record not found." }); return; }
  res.json(DeleteGuestPhotoResponse.parse(updated));
});

export default router;
