import { Router, type IRouter } from "express";
import healthRouter from "./health";
import visitsRouter from "./visits";
import reportsRouter from "./reports";
import staffTimeRouter from "./staff-time";
import guestPhotosRouter from "./guest-photos";
import privacyRouter from "./privacy";

const router: IRouter = Router();

router.use(healthRouter);
router.use(visitsRouter);
router.use(reportsRouter);
router.use(staffTimeRouter);
router.use(guestPhotosRouter);
router.use(privacyRouter);

export default router;
