import { Router, type IRouter } from "express";
import { and, eq } from "drizzle-orm";
import { db, clientsTable, privacySettingsTable } from "@workspace/db";
import {
  GetPrivacySettingsResponse, SavePrivacySettingsBody, SavePrivacySettingsResponse,
  PreviewPrivacyRetentionBody, PreviewPrivacyRetentionResponse,
  RemoveClientDescriptionBody, RemoveClientDescriptionParams, RemoveClientDescriptionResponse,
} from "@workspace/api-zod";
import { requireUser } from "../middlewares/require-user";
import {
  lockPrivacy, affectedProfiles, issuePreview, readPreview, matchesPreview,
  clearExpiredProfiles, retentionCutoff,
} from "../lib/privacy";

const router: IRouter = Router();
router.use(requireUser);

router.get("/privacy", async (_req, res): Promise<void> => {
  const [settings] = await db.select().from(privacySettingsTable)
    .where(eq(privacySettingsTable.ownerId, res.locals.userId));
  res.json(GetPrivacySettingsResponse.parse({ retentionDays: settings?.retentionDays ?? null }));
});

router.post("/privacy/preview", async (req, res): Promise<void> => {
  const body = PreviewPrivacyRetentionBody.safeParse(req.body);
  if (!body.success) { res.status(400).json({ error: "Choose a whole number of days from 1 to 3650." }); return; }
  const ownerId = res.locals.userId as string;
  const preview = await db.transaction(async (tx) => {
    const settings = await lockPrivacy(tx, ownerId);
    const cutoff = retentionCutoff(body.data.retentionDays);
    const rows = await affectedProfiles(tx, ownerId, cutoff);
    return issuePreview(ownerId, body.data.retentionDays, cutoff, rows, settings.updatedAt);
  });
  res.json(PreviewPrivacyRetentionResponse.parse(preview));
});

router.put("/privacy", async (req, res): Promise<void> => {
  const body = SavePrivacySettingsBody.safeParse(req.body);
  if (!body.success) { res.status(400).json({ error: "Invalid retention settings." }); return; }
  const { retentionDays, confirmed, previewToken } = body.data;
  if (retentionDays !== null && (confirmed !== true || !previewToken)) {
    res.status(400).json({ error: "Preview affected guests and explicitly confirm before enabling retention." }); return;
  }
  const ownerId = res.locals.userId as string;
  const saved = await db.transaction(async (tx) => {
    const settings = await lockPrivacy(tx, ownerId);
    if (retentionDays !== null) {
      const preview = readPreview(previewToken!, ownerId, retentionDays, settings.updatedAt);
      if (!preview) return false;
      const rows = await affectedProfiles(tx, ownerId, preview.cutoff);
      if (!matchesPreview(rows, preview.fingerprint)) return false;
      // Only remove the records covered by this confirmed, still-current preview.
      await clearExpiredProfiles(tx, ownerId, preview.cutoff);
    }
    await tx.update(privacySettingsTable).set({ retentionDays, updatedAt: new Date() })
      .where(eq(privacySettingsTable.ownerId, ownerId));
    return true;
  });
  if (!saved) { res.status(409).json({ error: "This preview expired or records/settings changed. Preview again before confirming." }); return; }
  res.json(SavePrivacySettingsResponse.parse({ retentionDays }));
});

router.post("/clients/:clientId/description-removal", async (req, res): Promise<void> => {
  const params = RemoveClientDescriptionParams.safeParse(req.params);
  const body = RemoveClientDescriptionBody.safeParse(req.body);
  if (!params.success || !body.success || body.data.confirmed !== true) {
    res.status(400).json({ error: "Explicit confirmation is required to remove a previous description." }); return;
  }
  const ownerId = res.locals.userId as string;
  const removed = await db.transaction(async (tx) => {
    await lockPrivacy(tx, ownerId);
    const rows = await tx.update(clientsTable).set({ description: null, sensitiveUpdatedAt: new Date() })
      .where(and(eq(clientsTable.id, params.data.clientId), eq(clientsTable.ownerId, ownerId)))
      .returning({ id: clientsTable.id });
    return rows.length > 0;
  });
  if (!removed) { res.status(404).json({ error: "Guest record not found." }); return; }
  res.json(RemoveClientDescriptionResponse.parse({ removed: true }));
});

export default router;
