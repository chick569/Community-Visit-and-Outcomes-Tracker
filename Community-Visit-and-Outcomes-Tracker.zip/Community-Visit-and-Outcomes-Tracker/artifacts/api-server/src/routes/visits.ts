import { randomBytes } from "node:crypto";
import { Router, type IRouter } from "express";
import { and, asc, desc, eq, gte, ilike, isNotNull, isNull, lt, sql } from "drizzle-orm";
import { db, clientsTable, visitsTable } from "@workspace/db";
import {
  ListClientsQueryParams, ListClientsResponse, CreateClientResponse,
  ListVisitsQueryParams, ListVisitsResponse, CreateVisitBody, CreateVisitResponse,
  UpdateVisitParams, UpdateVisitBody, UpdateVisitResponse,
  UpdateClientParams, UpdateClientBody, UpdateClientResponse,
  GetClientSummaryParams, GetClientSummaryResponse,
  ListSupportLocationsResponse,
} from "@workspace/api-zod";
import { requireUser } from "../middlewares/require-user";
import { dateQuery, nextDay, visitColumns, withStatus } from "../lib/visit-data";
import { hasDemographics, lockPrivacy } from "../lib/privacy";

const router: IRouter = Router();
router.use(requireUser);

const normalizeLocation = (value?: string | null) => value?.trim().replace(/\s+/g, " ") || null;

router.get("/support-locations", async (_req, res): Promise<void> => {
  const rows = await db.selectDistinct({ location: visitsTable.location }).from(visitsTable)
    .where(and(eq(visitsTable.ownerId, res.locals.userId), isNotNull(visitsTable.location)))
    .orderBy(asc(visitsTable.location));
  res.json(ListSupportLocationsResponse.parse(rows.map((row) => row.location)));
});

async function findClientProfile(ownerId: string, clientId: string) {
  const [client] = await db.select({
    id: clientsTable.id, code: clientsTable.code, description: clientsTable.description, demographics: clientsTable.demographics,
    createdAt: clientsTable.createdAt, photoUpdatedAt: clientsTable.photoUpdatedAt,
    visitCount: sql<number>`count(${visitsTable.id})::int`,
    lastVisitAt: sql<Date | null>`max(${visitsTable.arrivedAt})`,
  }).from(clientsTable).leftJoin(visitsTable, and(
    eq(visitsTable.clientId, clientsTable.id), eq(visitsTable.ownerId, ownerId),
  )).where(and(eq(clientsTable.id, clientId), eq(clientsTable.ownerId, ownerId)))
    .groupBy(clientsTable.id);
  return client;
}

router.get("/clients", async (req, res): Promise<void> => {
  const parsed = ListClientsQueryParams.safeParse(req.query);
  if (!parsed.success) { res.status(400).json({ error: "Invalid guest search." }); return; }
  const filters = [eq(clientsTable.ownerId, res.locals.userId)];
  if (parsed.data.search) filters.push(ilike(clientsTable.code, `%${parsed.data.search.replace(/[%_\\]/g, "\\$&")}%`));
  const rows = await db.select({
    id: clientsTable.id, code: clientsTable.code, description: clientsTable.description, demographics: clientsTable.demographics, createdAt: clientsTable.createdAt, photoUpdatedAt: clientsTable.photoUpdatedAt,
    visitCount: sql<number>`count(${visitsTable.id})::int`,
    lastVisitAt: sql<Date | null>`max(${visitsTable.arrivedAt})`,
  }).from(clientsTable).leftJoin(visitsTable, and(
    eq(visitsTable.clientId, clientsTable.id), eq(visitsTable.ownerId, res.locals.userId),
  )).where(and(...filters)).groupBy(clientsTable.id).orderBy(desc(clientsTable.createdAt));
  res.json(ListClientsResponse.parse(rows));
});

router.post("/clients", async (_req, res): Promise<void> => {
  const [row] = await db.insert(clientsTable).values({
    ownerId: res.locals.userId, code: `G-${randomBytes(4).toString("hex").toUpperCase()}`,
  }).returning();
  res.status(201).json(CreateClientResponse.parse({ ...row, visitCount: 0, lastVisitAt: null }));
});

router.patch("/clients/:clientId", async (req, res): Promise<void> => {
  const params = UpdateClientParams.safeParse(req.params);
  const body = UpdateClientBody.safeParse(req.body);
  if (!params.success || !body.success) {
    res.status(400).json({ error: "Provide a valid guest profile. Each selection must be 100 characters or fewer." }); return;
  }
  // Earlier free text may only be removed through the explicitly confirmed action.
  if (Object.prototype.hasOwnProperty.call(req.body, "description")) {
    res.status(400).json({ error: "Use the confirmed description removal action." }); return;
  }
  if (body.data.demographics === undefined) {
    res.status(400).json({ error: "No profile changes provided." }); return;
  }
  const demographics = body.data.demographics && {
    ...body.data.demographics,
    races: [...new Set((body.data.demographics.races ?? []).map((v) => v.trim()).filter(Boolean))],
    languages: [...new Set((body.data.demographics.languages ?? []).map((v) => v.trim()).filter(Boolean))],
    gender: body.data.demographics.gender?.trim() || null,
    sex: body.data.demographics.sex?.trim() || null,
    nationality: body.data.demographics.nationality?.trim() || null,
    ethnicity: body.data.demographics.ethnicity?.trim() || null,
    ageRange: body.data.demographics.ageRange ?? null,
  };
  if (demographics && [demographics.races, demographics.languages].some((values) => values.includes("Prefer not to say") && values.length > 1)) {
    res.status(400).json({ error: "Choose either reported values or Prefer not to say, not both." }); return;
  }
  const ownerId = res.locals.userId as string;

  const updated = await db.transaction(async (tx) => {
    await lockPrivacy(tx, ownerId);
    const [row] = await tx.update(clientsTable)
    .set({
      demographics: demographics && hasDemographics(demographics) ? demographics : {},
      sensitiveUpdatedAt: new Date(),
    })
    .where(and(eq(clientsTable.id, params.data.clientId), eq(clientsTable.ownerId, ownerId)))
    .returning({ id: clientsTable.id });
    return row;
  });
  if (!updated) { res.status(404).json({ error: "Guest record not found." }); return; }
  res.json(UpdateClientResponse.parse(await findClientProfile(ownerId, updated.id)));
});

router.get("/clients/:clientId/summary", async (req, res): Promise<void> => {
  const params = GetClientSummaryParams.safeParse(req.params);
  if (!params.success) { res.status(400).json({ error: "Invalid guest record." }); return; }
  const ownerId = res.locals.userId as string;

  const client = await findClientProfile(ownerId, params.data.clientId);
  if (!client) { res.status(404).json({ error: "Guest record not found." }); return; }
  // Select only guest-facing fields. Staff notes and outcomes never enter this payload.
  const visits = await db.select({
    id: visitsTable.id, arrivedAt: visitsTable.arrivedAt,
    departedAt: visitsTable.departedAt, service: visitsTable.service, location: visitsTable.location,
  }).from(visitsTable).where(and(
    eq(visitsTable.clientId, client.id), eq(visitsTable.ownerId, ownerId),
  )).orderBy(desc(visitsTable.arrivedAt));
  res.json(GetClientSummaryResponse.parse({ client, visits }));
});

router.get("/visits", async (req, res): Promise<void> => {
  const parsed = ListVisitsQueryParams.safeParse(dateQuery(req.query));
  if (!parsed.success) { res.status(400).json({ error: "Use valid dates and visit filters." }); return; }
  const { status, dateFrom, dateTo, search } = parsed.data;
  if (dateFrom && dateTo && dateFrom > dateTo) { res.status(400).json({ error: "Start date must be before end date." }); return; }
  const filters = [eq(visitsTable.ownerId, res.locals.userId), eq(clientsTable.ownerId, res.locals.userId)];
  if (status === "on-site") filters.push(isNull(visitsTable.departedAt));
  if (status === "completed") filters.push(isNotNull(visitsTable.departedAt));
  if (dateFrom) filters.push(gte(visitsTable.arrivedAt, dateFrom));
  if (dateTo) filters.push(lt(visitsTable.arrivedAt, nextDay(dateTo)));
  if (search) filters.push(ilike(clientsTable.code, `%${search.replace(/[%_\\]/g, "\\$&")}%`));
  const rows = await db.select(visitColumns).from(visitsTable)
    .innerJoin(clientsTable, eq(visitsTable.clientId, clientsTable.id))
    .where(and(...filters)).orderBy(desc(visitsTable.arrivedAt));
  res.json(ListVisitsResponse.parse(rows.map(withStatus)));
});

router.post("/visits", async (req, res): Promise<void> => {
  const parsed = CreateVisitBody.safeParse(req.body);
  if (!parsed.success) { res.status(400).json({ error: "Choose a guest and service. Notes must be 2,000 characters or fewer; support locations, 200 or fewer." }); return; }
  const [client] = await db.select().from(clientsTable).where(and(
    eq(clientsTable.id, parsed.data.clientId), eq(clientsTable.ownerId, res.locals.userId),
  ));
  if (!client) { res.status(404).json({ error: "Guest record not found." }); return; }
  const rows = await db.insert(visitsTable).values({
    ownerId: res.locals.userId, clientId: client.id, service: parsed.data.service,
    notes: parsed.data.notes?.trim() || null, outcome: parsed.data.outcome ?? null,
    location: normalizeLocation(parsed.data.location),
  }).onConflictDoNothing().returning();
  if (!rows[0]) { res.status(409).json({ error: "This guest is already on-site. Record their departure before starting another visit." }); return; }
  res.status(201).json(CreateVisitResponse.parse(withStatus({ ...rows[0], clientCode: client.code })));
});

router.patch("/visits/:visitId", async (req, res): Promise<void> => {
  const params = UpdateVisitParams.safeParse(req.params);
  const parsed = UpdateVisitBody.safeParse(req.body);
  if (!params.success || !parsed.success) { res.status(400).json({ error: "Invalid visit details." }); return; }
  const [current] = await db.select(visitColumns).from(visitsTable)
    .innerJoin(clientsTable, eq(visitsTable.clientId, clientsTable.id))
    .where(and(eq(visitsTable.id, params.data.visitId), eq(visitsTable.ownerId, res.locals.userId)));

  if (!current) { res.status(404).json({ error: "Visit not found." }); return; }
  const { departedAt, notes, outcome, location } = parsed.data;
  if (departedAt && (departedAt < current.arrivedAt || departedAt.getTime() > Date.now() + 60_000)) {
    res.status(400).json({ error: "Departure must be after arrival and cannot be in the future." }); return;
  }
  const update = {
    ...(departedAt !== undefined ? { departedAt } : {}),
    ...(notes !== undefined ? { notes: notes?.trim() || null } : {}),
    ...(outcome !== undefined ? { outcome } : {}),
    ...(location !== undefined ? { location: normalizeLocation(location) } : {}),
  };
  if (!Object.keys(update).length) { res.status(400).json({ error: "No changes provided." }); return; }
  // Reopening a completed visit could conflict with a newer active visit.
  if (departedAt === null) {
    res.status(400).json({ error: "Completed visits cannot be reopened. Start a new visit instead." }); return;
  }
  const [row] = await db.update(visitsTable).set(update).where(and(
    eq(visitsTable.id, params.data.visitId), eq(visitsTable.ownerId, res.locals.userId),
  )).returning();
  res.json(UpdateVisitResponse.parse(withStatus({ ...row, clientCode: current.clientCode })));
});

export default router;
