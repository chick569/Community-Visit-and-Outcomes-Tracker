import assert from "node:assert/strict";
import { randomUUID } from "node:crypto";
import { once } from "node:events";
import { test } from "node:test";
import express from "express";
import { eq } from "drizzle-orm";
import { db, pool, clientsTable, visitsTable, staffShiftsTable, privacySettingsTable } from "@workspace/db";
import privacyRouter from "../src/routes/privacy";
import visitsRouter from "../src/routes/visits";
import reportsRouter from "../src/routes/reports";
import { runAccountRetention } from "../src/lib/privacy";

// Integration harness only: emulate the auth object Clerk attaches to trusted requests.
// The production app never installs this middleware or accepts this header.
test("privacy confirmations, ownership, previews, retention and operational preservation", async () => {
  const owner = `privacy-test-${randomUUID()}`;
  const foreign = `privacy-test-${randomUUID()}`;
  const app = express();
  app.use(express.json());
  app.use((req, _res, next) => {
    const auth = Object.assign(
      () => ({ userId: req.headers["x-test-owner"] ?? null, tokenType: "session_token" }),
      { [Symbol.for("@clerk/express.auth")]: true },
    );
    Object.assign(req, { auth });
    next();
  });
  app.use(privacyRouter, visitsRouter, reportsRouter);
  const server = app.listen(0, "127.0.0.1");
  await once(server, "listening");
  const address = server.address();
  assert(address && typeof address !== "string");
  const request = async (path: string, method = "GET", body?: unknown, account: string | null = owner) => {
    const response = await fetch(`http://127.0.0.1:${address.port}${path}`, {
      method, headers: { "Content-Type": "application/json", ...(account ? { "x-test-owner": account } : {}) },
      body: body === undefined ? undefined : JSON.stringify(body),
    });
    return { status: response.status, data: await response.json() };
  };
  const getClient = async (id: string) => (await db.select().from(clientsTable).where(eq(clientsTable.id, id)))[0];
  try {
    const old = new Date(Date.now() - 120 * 86_400_000);
    const [guest, other, recent, empty] = await db.insert(clientsTable).values([
      { ownerId: owner, code: "TEST-OLD", description: "Synthetic test only", demographics: { gender: "Prefer not to say" }, createdAt: old },
      { ownerId: foreign, code: "TEST-OTHER", description: "Synthetic test only", demographics: { gender: "Prefer not to say" }, createdAt: old },
      { ownerId: owner, code: "TEST-RECENT", description: "Synthetic test only", createdAt: old, sensitiveUpdatedAt: new Date() },
      { ownerId: owner, code: "TEST-EMPTY", demographics: { races: [], languages: [], gender: null }, createdAt: old },
    ]).returning();
    await db.insert(visitsTable).values({
      ownerId: owner, clientId: guest.id, service: "meals", notes: "Synthetic test only",
      arrivedAt: new Date(Date.now() - 3600_000), departedAt: new Date(),
    });
    await db.insert(staffShiftsTable).values({ ownerId: owner });
    const visitsBefore = await db.select().from(visitsTable).where(eq(visitsTable.ownerId, owner));
    const shiftsBefore = await db.select().from(staffShiftsTable).where(eq(staffShiftsTable.ownerId, owner));
    const today = new Date().toISOString().slice(0, 10);
    const reportPath = `/reports?dateFrom=${today}&dateTo=${today}`;
    const reportBefore = await request(reportPath);

    assert.equal((await request("/privacy", "GET", undefined, null)).status, 401);
    assert.equal((await request("/privacy")).data.retentionDays, null);
    await runAccountRetention(owner, new Date(Date.now() + 1000 * 86_400_000));
    assert.equal(Boolean((await getClient(guest.id)).description), true, "default off must not remove old details");
    assert.equal((await request("/privacy", "PUT", { retentionDays: 30 })).status, 400);
    assert.equal((await request("/privacy/preview", "POST", { retentionDays: 1.5 })).status, 400);
    assert.equal((await request("/privacy/preview", "POST", { retentionDays: 0 })).status, 400);
    assert.equal((await request("/privacy/preview", "POST", { retentionDays: 3651 })).status, 400);
    const preview = (await request("/privacy/preview", "POST", { retentionDays: 30 })).data;
    assert.deepEqual(preview.records, [{ code: guest.code, hasDescription: true, hasDemographics: true }]);
    assert.equal(JSON.stringify(preview).includes("Synthetic test only"), false);
    assert.equal(Boolean((await getClient(guest.id)).description), true, "preview must be read-only");
    assert.equal((await request("/privacy", "PUT", { retentionDays: 30, previewToken: preview.previewToken, confirmed: false })).status, 400);
    assert.equal((await request("/privacy", "PUT", { retentionDays: 30, previewToken: preview.previewToken, confirmed: true }, foreign)).status, 409);
    assert.equal((await request("/privacy", "PUT", { retentionDays: 31, previewToken: preview.previewToken, confirmed: true })).status, 409);
    assert.equal((await request("/privacy", "PUT", { retentionDays: 30, previewToken: preview.previewToken + "x", confirmed: true })).status, 409);
    assert.equal((await request(`/clients/${other.id}/description-removal`, "POST", { confirmed: true })).status, 404);
    assert.equal((await request(`/clients/${other.id}`, "PATCH", { demographics: {} })).status, 404);
    assert.equal((await request(`/clients/${guest.id}/summary`, "GET", undefined, foreign)).status, 404);
    assert.equal((await request(`/clients/${guest.id}/description-removal`, "POST", {})).status, 400);
    assert.equal((await request(`/clients/${guest.id}`, "PATCH", { description: null })).status, 400);

    // A profile edit makes an earlier preview invalid.
    assert.equal((await request(`/clients/${guest.id}`, "PATCH", { demographics: { gender: "Prefer not to say" } })).status, 200);
    assert.equal((await request("/privacy", "PUT", { retentionDays: 30, previewToken: preview.previewToken, confirmed: true })).status, 409);
    await db.update(clientsTable).set({ sensitiveUpdatedAt: old }).where(eq(clientsTable.id, guest.id));
    const fresh = (await request("/privacy/preview", "POST", { retentionDays: 30 })).data;
    assert.equal((await request("/privacy", "PUT", { retentionDays: 30, previewToken: fresh.previewToken, confirmed: true })).status, 200);
    const removed = await getClient(guest.id);
    assert.equal(removed.description, null);
    assert.deepEqual(removed.demographics, {});
    assert.equal(removed.code, guest.code);
    assert.equal(Boolean((await getClient(other.id)).description), true, "other account untouched");
    assert.equal(Boolean((await getClient(recent.id)).description), true, "recent profile untouched");
    assert.deepEqual((await request(reportPath)).data, reportBefore.data);
    assert.deepEqual(await db.select().from(visitsTable).where(eq(visitsTable.ownerId, owner)), visitsBefore);
    assert.deepEqual(await db.select().from(staffShiftsTable).where(eq(staffShiftsTable.ownerId, owner)), shiftsBefore);

    // Disabled retention must remain inert even when a previously enabled worker is invoked.
    assert.equal((await request("/privacy", "PUT", { retentionDays: null })).status, 200);
    await db.update(clientsTable).set({ sensitiveUpdatedAt: old }).where(eq(clientsTable.id, recent.id));
    await runAccountRetention(owner);
    assert.equal(Boolean((await getClient(recent.id)).description), true);
    const [manual] = await db.insert(clientsTable).values({
      ownerId: owner, code: "TEST-MANUAL", description: "Synthetic test only", demographics: { languages: ["English"] },
    }).returning();
    assert.equal((await request(`/clients/${manual.id}/description-removal`, "POST", { confirmed: true })).status, 200);
    assert.equal((await getClient(manual.id)).description, null);
    assert.deepEqual((await getClient(manual.id)).demographics, { languages: ["English"] });
    // Automatic worker shares exactly the confirmed removal path, scoped to one account.
    const finalPreview = (await request("/privacy/preview", "POST", { retentionDays: 30 })).data;
    await request("/privacy", "PUT", { retentionDays: 30, previewToken: finalPreview.previewToken, confirmed: true });
    await db.update(clientsTable).set({ sensitiveUpdatedAt: old }).where(eq(clientsTable.id, manual.id));
    await runAccountRetention(owner);
    assert.deepEqual((await getClient(manual.id)).demographics, {});
    assert.deepEqual(await db.select().from(visitsTable).where(eq(visitsTable.ownerId, owner)), visitsBefore);
    assert.equal((await getClient(empty.id)).code, empty.code);
  } finally {
    // Remove only records belonging to the two accounts created by this test.
    for (const ownerId of [owner, foreign]) {
      await db.delete(visitsTable).where(eq(visitsTable.ownerId, ownerId));
      await db.delete(staffShiftsTable).where(eq(staffShiftsTable.ownerId, ownerId));
      await db.delete(clientsTable).where(eq(clientsTable.ownerId, ownerId));
      await db.delete(privacySettingsTable).where(eq(privacySettingsTable.ownerId, ownerId));
    }
    await new Promise<void>((resolve) => server.close(() => resolve()));
    await pool.end();
  }
});
