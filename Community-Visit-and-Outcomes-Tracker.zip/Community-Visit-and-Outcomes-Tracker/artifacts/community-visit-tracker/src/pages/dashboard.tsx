import { useState } from 'react';
import { Link } from 'wouter';
import { ArrowRight, Plus } from 'lucide-react';
import { getGetDashboardQueryKey, useGetDashboard, type Visit } from '@workspace/api-client-react';
import { Bar, EmptyState, ErrorPanel, GuestCode, PageHead, ServiceTag, StatusPill } from '@/components/bits';
import { CheckInDialog } from '@/components/check-in-dialog';
import { VisitDialog } from '@/components/visit-dialog';
import { SERVICE_TONE, duration, fmtTime, serviceLabel } from '@/lib/format';

export default function Dashboard() {
  const q = useGetDashboard({ query: { refetchInterval: 30000, queryKey: getGetDashboardQueryKey() } });
  const [edit, setEdit] = useState<Visit | null>(null);
  const [checkIn, setCheckIn] = useState(false);
  const d = q.data;
  const today = new Date().toLocaleDateString([], { weekday: 'long', month: 'long', day: 'numeric', timeZone: 'UTC' });
  const totalSvc = d?.serviceBreakdown.reduce((a, s) => a + s.visits, 0) ?? 0;

  return (
    <>
      <PageHead kicker={`Daily log · ${today} · UTC`} title="On the floor today">
        <span className="font-code flex items-center gap-2 text-xs text-muted-foreground">
          <span className={q.isFetching ? 'h-1.5 w-1.5 animate-pulse rounded-full bg-primary' : 'h-1.5 w-1.5 rounded-full bg-primary/40'} />
          Live · refreshes every 30s
        </span>
      </PageHead>

      {q.isError ? (
        <ErrorPanel error={q.error} onRetry={() => q.refetch()} />
      ) : (
        <div className="space-y-8">
          <section className="rise grid grid-cols-2 overflow-hidden rounded-md border border-foreground/15 bg-card md:grid-cols-5">
            <div className="col-span-2 row-span-1 bg-[hsl(198_42%_14%)] p-6 text-[hsl(40_30%_94%)] md:col-span-1">
              <p className="text-xs uppercase tracking-widest text-[hsl(14_80%_66%)]">On site now</p>
              {q.isLoading ? <Bar className="mt-3 h-14 w-20 bg-white/10" /> : (
                <p data-testid="text-on-site" className="font-display mt-2 text-7xl font-semibold leading-none">{d?.currentlyOnSite}</p>
              )}
            </div>
            {[
              ['Visits today', d?.todayVisits, 'today-visits'],
              ['People today', d?.uniquePeopleToday, 'people-today'],
              ['Departures', d?.departuresToday, 'departures'],
              ['This month', d?.monthVisits, 'month-visits'],
            ].map(([label, val, id]) => (
              <div key={id as string} className="border-l border-t border-border p-6 md:border-t-0">
                <p className="text-xs uppercase tracking-widest text-muted-foreground">{label}</p>
                {q.isLoading ? <Bar className="mt-3 h-10 w-14" /> : (
                  <p data-testid={`text-${id}`} className="font-display mt-2 text-5xl font-semibold leading-none">{val as number}</p>
                )}
              </div>
            ))}
          </section>

          <div className="grid gap-8 lg:grid-cols-[1fr_320px]">
            <section className="rise" style={{ animationDelay: '80ms' }}>
              <div className="mb-3 flex items-baseline justify-between">
                <h2 className="font-display text-2xl font-semibold">Recent arrivals</h2>
                <Link href="/visits" data-testid="link-all-visits" className="inline-flex items-center gap-1 text-sm text-primary hover:underline">All visits <ArrowRight className="h-3.5 w-3.5" /></Link>
              </div>
              {q.isLoading ? (
                <div className="space-y-2">{[0, 1, 2, 3].map((i) => <Bar key={i} className="h-14" />)}</div>
              ) : !d?.recentVisits.length ? (
                <EmptyState
                  title="A quiet floor"
                  body="No visits logged yet. Check in your first guest when they arrive."
                  action={<button data-testid="button-empty-checkin" onClick={() => setCheckIn(true)} className="inline-flex items-center gap-2 rounded-md bg-primary px-4 py-2 text-sm font-semibold text-primary-foreground"><Plus className="h-4 w-4" />Check in a guest</button>}
                />
              ) : (
                <ul className="divide-y divide-border overflow-hidden rounded-md border border-border bg-card">
                  {d.recentVisits.map((v) => (
                    <li key={v.id}>
                      <button data-testid={`row-recent-${v.id}`} onClick={() => setEdit(v)} className="grid w-full grid-cols-[auto_1fr_auto] items-center gap-4 px-4 py-3 text-left transition hover:bg-secondary/60">
                        <span className="font-code w-16 text-sm text-muted-foreground">{fmtTime(v.arrivedAt)}</span>
                        <span className="flex flex-wrap items-center gap-3">
                          <GuestCode code={v.clientCode} />
                          <ServiceTag service={v.service} />
                          {v.location && <span className="w-full break-words text-left text-xs text-muted-foreground">Support location: {v.location}</span>}
                        </span>
                        <span className="flex items-center gap-3">
                          <span className="font-code hidden text-xs text-muted-foreground sm:inline">{duration(v.arrivedAt, v.departedAt)}</span>
                          <StatusPill status={v.status} />
                        </span>
                      </button>
                    </li>
                  ))}
                </ul>
              )}
            </section>

            <aside className="rise" style={{ animationDelay: '160ms' }}>
              <h2 className="font-display mb-3 text-2xl font-semibold">Services this month</h2>
              <div className="rounded-md border border-border bg-card p-5">
                {q.isLoading ? <div className="space-y-3">{[0, 1, 2].map((i) => <Bar key={i} className="h-6" />)}</div> : totalSvc === 0 ? (
                  <p className="text-sm text-muted-foreground">Breakdown appears after the first check-in.</p>
                ) : (
                  <>
                    <div className="mb-5 flex h-3 overflow-hidden rounded-full">
                      {d!.serviceBreakdown.filter((s) => s.visits > 0).map((s) => (
                        <div key={s.service} style={{ width: `${(s.visits / totalSvc) * 100}%`, background: SERVICE_TONE[s.service] ?? SERVICE_TONE.other }} />
                      ))}
                    </div>
                    <ul className="space-y-2.5">
                      {d!.serviceBreakdown.map((s) => (
                        <li key={s.service} className="flex items-center justify-between text-sm" data-testid={`text-service-${s.service}`}>
                          <span className="flex items-center gap-2"><span className="h-2 w-2 rounded-[2px]" style={{ background: SERVICE_TONE[s.service] ?? SERVICE_TONE.other }} />{serviceLabel(s.service)}</span>
                          <span className="font-code">{s.visits}</span>
                        </li>
                      ))}
                    </ul>
                  </>
                )}
              </div>
            </aside>
          </div>
        </div>
      )}
      <VisitDialog visit={edit} onClose={() => setEdit(null)} />
      <CheckInDialog open={checkIn} onOpenChange={setCheckIn} />
    </>
  );
}
