import { useEffect, useState } from 'react';
import { Loader2, LogOut, Pencil, Search, X } from 'lucide-react';
import { getListVisitsQueryKey, useListVisits, useUpdateVisit, type ListVisitsStatus, type Visit } from '@workspace/api-client-react';
import { Bar, EmptyState, ErrorPanel, GuestCode, PageHead, ServiceTag, StatusPill } from '@/components/bits';
import { VisitDialog } from '@/components/visit-dialog';
import { useToast } from '@/hooks/use-toast';
import { duration, errorMessage, fmtDay, fmtTime, outcomeLabel, useInvalidateAll } from '@/lib/format';
import { cn } from '@/lib/utils';

export default function Visits() {
  const [status, setStatus] = useState<ListVisitsStatus>('all');
  const [search, setSearch] = useState('');
  const [debounced, setDebounced] = useState('');
  const [dateFrom, setDateFrom] = useState('');
  const [dateTo, setDateTo] = useState('');
  const [edit, setEdit] = useState<Visit | null>(null);
  const update = useUpdateVisit();
  const invalidate = useInvalidateAll();
  const { toast } = useToast();

  useEffect(() => {
    const t = setTimeout(() => setDebounced(search.trim()), 250);
    return () => clearTimeout(t);
  }, [search]);

  const params = {
    status,
    ...(debounced ? { search: debounced } : {}),
    ...(dateFrom ? { dateFrom } : {}),
    ...(dateTo ? { dateTo } : {}),
  };
  const q = useListVisits(params, { query: { refetchInterval: 30000, queryKey: getListVisitsQueryKey(params) } });
  const rows = q.data ?? [];
  const filtered = status !== 'all' || !!debounced || !!dateFrom || !!dateTo;

  const checkout = (v: Visit) =>
    update.mutate(
      { visitId: v.id, data: { departedAt: new Date().toISOString() } },
      {
        onSuccess: (r) => { invalidate(); toast({ title: 'Departure recorded', description: `Guest ${r.clientCode}` }); },
        onError: (e) => toast({ title: 'Check-out failed', description: errorMessage(e), variant: 'destructive' }),
      },
    );

  const clear = () => { setStatus('all'); setSearch(''); setDateFrom(''); setDateTo(''); };

  return (
    <>
      <PageHead kicker="Ledger" title="Visits" />

      <div className="rise mb-5 flex flex-col gap-3 lg:flex-row lg:items-center">
        <div className="flex gap-1 rounded-md bg-secondary p-1 text-sm font-medium">
          {(['all', 'on-site', 'completed'] as const).map((s) => (
            <button key={s} data-testid={`filter-status-${s}`} onClick={() => setStatus(s)} className={cn('rounded px-3 py-1.5 capitalize transition', status === s ? 'bg-card shadow-sm' : 'text-muted-foreground hover:text-foreground')}>
              {s === 'on-site' ? 'On site' : s}
            </button>
          ))}
        </div>
        <div className="relative flex-1">
          <Search className="absolute left-3 top-1/2 h-4 w-4 -translate-y-1/2 text-muted-foreground" />
          <input data-testid="input-search-visits" value={search} onChange={(e) => setSearch(e.target.value)} maxLength={40} placeholder="Guest code" className="font-code w-full rounded-md border border-input bg-card py-2 pl-9 pr-3 text-sm uppercase outline-none focus:ring-2 focus:ring-ring/40" />
        </div>
        <div className="flex items-center gap-2 text-sm">
          <input data-testid="input-date-from" type="date" value={dateFrom} onChange={(e) => setDateFrom(e.target.value)} className="rounded-md border border-input bg-card px-2 py-1.5" />
          <span className="text-muted-foreground">to</span>
          <input data-testid="input-date-to" type="date" value={dateTo} onChange={(e) => setDateTo(e.target.value)} className="rounded-md border border-input bg-card px-2 py-1.5" />
          {filtered && <button data-testid="button-clear-filters" onClick={clear} className="rounded-md p-2 text-muted-foreground hover:bg-secondary" title="Clear filters"><X className="h-4 w-4" /></button>}
        </div>
      </div>

      {q.isError ? (
        <ErrorPanel error={q.error} onRetry={() => q.refetch()} />
      ) : q.isLoading ? (
        <div className="space-y-2">{[0, 1, 2, 3, 4].map((i) => <Bar key={i} className="h-12" />)}</div>
      ) : rows.length === 0 ? (
        <EmptyState
          title={filtered ? 'Nothing matches' : 'No visits yet'}
          body={filtered ? 'Try widening the date range or clearing the code search.' : 'Use Check in in the top bar to log the first arrival.'}
          action={filtered ? <button onClick={clear} className="rounded-md border border-border bg-card px-4 py-2 text-sm font-medium">Clear filters</button> : undefined}
        />
      ) : (
        <div className="rise overflow-x-auto rounded-md border border-border bg-card">
          <table className="w-full min-w-[760px] text-sm">
            <thead>
              <tr className="border-b border-foreground/15 text-left text-[11px] uppercase tracking-wider text-muted-foreground">
                <th className="px-4 py-2.5 font-semibold">Date</th>
                <th className="px-4 py-2.5 font-semibold">Guest</th>
                <th className="px-4 py-2.5 font-semibold">Service</th>
                <th className="px-4 py-2.5 font-semibold">Support location</th>
                <th className="px-4 py-2.5 font-semibold">In / Out</th>
                <th className="px-4 py-2.5 font-semibold">Outcome</th>
                <th className="px-4 py-2.5 font-semibold">Status</th>
                <th className="px-4 py-2.5" />
              </tr>
            </thead>
            <tbody className="divide-y divide-border">
              {rows.map((v) => (
                <tr key={v.id} data-testid={`row-visit-${v.id}`} className="group transition hover:bg-secondary/50">
                  <td className="whitespace-nowrap px-4 py-2.5">{fmtDay(v.arrivedAt)}</td>
                  <td className="px-4 py-2.5"><GuestCode code={v.clientCode} /></td>
                  <td className="px-4 py-2.5"><ServiceTag service={v.service} /></td>
                  <td data-testid={`text-visit-location-${v.id}`} className="max-w-[220px] break-words px-4 py-2.5 text-xs text-muted-foreground">{v.location || 'Not recorded'}</td>
                  <td className="font-code whitespace-nowrap px-4 py-2.5 text-xs">
                    {fmtTime(v.arrivedAt)} <span className="text-muted-foreground">→</span> {v.departedAt ? fmtTime(v.departedAt) : '…'}
                    <span className="ml-2 text-muted-foreground">{duration(v.arrivedAt, v.departedAt)}</span>
                  </td>
                  <td className="px-4 py-2.5 text-muted-foreground">
                    {outcomeLabel(v.outcome) ?? '—'}
                    {v.notes && <span className="ml-2 rounded bg-secondary px-1.5 text-[10px] uppercase tracking-wider" title="Has notes">note</span>}
                  </td>
                  <td className="px-4 py-2.5"><StatusPill status={v.status} /></td>
                  <td className="px-4 py-2.5">
                    <div className="flex justify-end gap-1">
                      {v.status === 'on-site' && (
                        <button data-testid={`button-checkout-${v.id}`} disabled={update.isPending && update.variables?.visitId === v.id} onClick={() => checkout(v)} className="inline-flex items-center gap-1 rounded-md border border-[hsl(14_80%_56%/0.4)] px-2 py-1 text-xs font-semibold text-accent-foreground transition hover:bg-accent disabled:opacity-50">
                          {update.isPending && update.variables?.visitId === v.id ? <Loader2 className="h-3 w-3 animate-spin" /> : <LogOut className="h-3 w-3" />} Out
                        </button>
                      )}
                      <button data-testid={`button-edit-${v.id}`} onClick={() => setEdit(v)} className="rounded-md p-1.5 text-muted-foreground transition hover:bg-secondary hover:text-foreground" title="Edit notes">
                        <Pencil className="h-3.5 w-3.5" />
                      </button>
                    </div>
                  </td>
                </tr>
              ))}
            </tbody>
          </table>
          <p className="font-code border-t border-border px-4 py-2 text-xs text-muted-foreground">{rows.length} entries</p>
        </div>
      )}
      <VisitDialog visit={edit} onClose={() => setEdit(null)} />
    </>
  );
}
