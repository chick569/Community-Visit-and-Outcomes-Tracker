import { useState } from 'react';
import { Download, Info, Printer } from 'lucide-react';
import { Bar as RBar, BarChart, CartesianGrid, ResponsiveContainer, Tooltip, XAxis, YAxis } from 'recharts';
import { useGetReport, getGetReportQueryKey, type ReportSummary } from '@workspace/api-client-react';
import { Bar, EmptyState, ErrorPanel, PageHead } from '@/components/bits';
import { SERVICE_TONE, serviceLabel, utcDaysAgo, utcMonthStart, utcToday } from '@/lib/format';
import { cn } from '@/lib/utils';

function toCsv(r: ReportSummary) {
  const lines: (string | number)[][] = [
    ['section', 'metric', 'value'],
    ['period', 'date_from_utc', r.dateFrom],
    ['period', 'date_to_utc', r.dateTo],
    ['totals', 'total_visits', r.totalVisits],
    ['totals', 'unique_people', r.uniquePeople],
    ['totals', 'completed_visits', r.completedVisits],
    ['totals', 'open_visits', r.openVisits],
    ['totals', 'average_visit_hours', r.averageVisitHours.toFixed(2)],
    ...r.serviceBreakdown.map((s) => ['service_visits', s.service, s.visits]),
    ...r.locationBreakdown.map((s) => ['location_visits', s.location ?? 'Not recorded', s.visits]),
    ...r.dailyBreakdown.flatMap((d) => [['daily_visits', d.date, d.visits], ['daily_people', d.date, d.people]]),
  ];
  return lines.map((l) => l.map((c) => {
    const text = String(c);
    // Location names are user-entered: prevent spreadsheet formula execution.
    const safe = typeof c === 'string' && /^\s*[=+\-@]/.test(text) ? `'${text}` : text;
    return `"${safe.replace(/"/g, '""')}"`;
  }).join(',')).join('\n');
}

const PRESETS = [
  { label: 'Month to date', from: () => utcMonthStart() },
  { label: 'Last 7 days', from: () => utcDaysAgo(6) },
  { label: 'Last 30 days', from: () => utcDaysAgo(29) },
  { label: 'Last 90 days', from: () => utcDaysAgo(89) },
];

export default function Reports() {
  const [dateFrom, setFrom] = useState(utcMonthStart());
  const [dateTo, setTo] = useState(utcToday());
  const valid = !!dateFrom && !!dateTo && dateFrom <= dateTo;
  const params = { dateFrom, dateTo };
  const q = useGetReport(params, { query: { enabled: valid, queryKey: getGetReportQueryKey(params) } });
  const r = q.data;

  const download = () => {
    if (!r) return;
    const blob = new Blob([toCsv(r)], { type: 'text/csv;charset=utf-8' });
    const url = URL.createObjectURL(blob);
    const a = document.createElement('a');
    a.href = url;
    a.download = `visit-impact_${r.dateFrom}_to_${r.dateTo}.csv`;
    a.click();
    URL.revokeObjectURL(url);
  };

  const maxSvc = Math.max(1, ...(r?.serviceBreakdown.map((s) => s.visits) ?? [1]));
  const completion = r && r.totalVisits ? Math.round((r.completedVisits / r.totalVisits) * 1000) / 10 : 0;

  return (
    <>
      <PageHead kicker="Impact summary" title="Reports">
        <button data-testid="button-download-csv" disabled={!r} onClick={download} className="inline-flex items-center gap-2 rounded-md border border-border bg-card px-3 py-2 text-sm font-medium hover:bg-secondary disabled:opacity-50">
          <Download className="h-4 w-4" /> CSV
        </button>
        <button data-testid="button-print" disabled={!r} onClick={() => window.print()} className="inline-flex items-center gap-2 rounded-md bg-primary px-3 py-2 text-sm font-semibold text-primary-foreground hover:bg-primary/90 disabled:opacity-50">
          <Printer className="h-4 w-4" /> Print
        </button>
      </PageHead>

      <div className="no-print rise mb-6 flex flex-col gap-3 md:flex-row md:items-center md:justify-between">
        <div className="flex flex-wrap gap-1.5">
          {PRESETS.map((p) => {
            const active = dateFrom === p.from() && dateTo === utcToday();
            return (
              <button key={p.label} data-testid={`button-preset-${p.label.replace(/\s/g, '-').toLowerCase()}`} onClick={() => { setFrom(p.from()); setTo(utcToday()); }} className={cn('rounded-full border px-3 py-1 text-xs font-medium transition', active ? 'border-foreground bg-foreground text-background' : 'border-border bg-card hover:border-foreground/40')}>
                {p.label}
              </button>
            );
          })}
        </div>
        <div className="flex items-center gap-2 text-sm">
          <input data-testid="input-report-from" type="date" value={dateFrom} onChange={(e) => setFrom(e.target.value)} className="rounded-md border border-input bg-card px-2 py-1.5" />
          <span className="text-muted-foreground">to</span>
          <input data-testid="input-report-to" type="date" value={dateTo} onChange={(e) => setTo(e.target.value)} className="rounded-md border border-input bg-card px-2 py-1.5" />
        </div>
      </div>

      <p className="mb-8 flex gap-2 rounded-md border border-primary/20 bg-primary/5 p-3 text-xs leading-relaxed text-foreground/80">
        <Info className="mt-0.5 h-3.5 w-3.5 shrink-0 text-primary" />
        Periods are counted by each visit's arrival date in UTC (Coordinated Universal Time), so late-evening visits may fall on the next calendar day. Reports and CSV exports contain only aggregate counts: no guest codes, notes, or individual records.
      </p>

      {!valid ? (
        <EmptyState title="Check the dates" body="The start date needs to be on or before the end date." />
      ) : q.isError ? (
        <ErrorPanel error={q.error} onRetry={() => q.refetch()} />
      ) : q.isLoading || !r ? (
        <div className="space-y-4"><Bar className="h-32" /><Bar className="h-64" /></div>
      ) : r.totalVisits === 0 ? (
        <EmptyState title="No visits in this period" body="Try a wider range, or check that visits were logged on these UTC dates." />
      ) : (
        <div className="space-y-10">
          <section className="rise">
            <p className="font-code text-xs text-muted-foreground">{r.dateFrom} — {r.dateTo} (UTC)</p>
            <p className="font-display mt-3 max-w-3xl text-3xl leading-snug md:text-4xl">
              We recorded <span data-testid="text-total-visits" className="text-primary">{r.totalVisits.toLocaleString()} visits</span> from{' '}
              <span data-testid="text-unique-people" className="text-[hsl(14_75%_48%)]">{r.uniquePeople.toLocaleString()} people</span>, with an average stay of{' '}
              <span data-testid="text-avg-hours">{r.averageVisitHours.toFixed(1)} hours</span>.
            </p>
            <dl className="mt-6 grid grid-cols-2 gap-px overflow-hidden rounded-md border border-border bg-border md:grid-cols-4">
              {[
                ['Completed', r.completedVisits],
                ['Still open', r.openVisits],
                ['Completion rate', `${completion}%`],
                ['Visits per person', (r.totalVisits / Math.max(1, r.uniquePeople)).toFixed(2)],
              ].map(([k, v]) => (
                <div key={k as string} className="bg-card p-4">
                  <dt className="text-xs uppercase tracking-wider text-muted-foreground">{k}</dt>
                  <dd className="font-display mt-1 text-3xl font-semibold">{v}</dd>
                </div>
              ))}
            </dl>
          </section>

          <div className="grid gap-8 lg:grid-cols-[1fr_340px]">
            <section className="rise">
              <h2 className="font-display mb-3 text-2xl font-semibold">Daily volume</h2>
              <div className="h-72 rounded-md border border-border bg-card p-4">
                <ResponsiveContainer width="100%" height="100%">
                  <BarChart data={r.dailyBreakdown} margin={{ left: -20, right: 4, top: 8 }}>
                    <CartesianGrid vertical={false} stroke="hsl(38 20% 86%)" />
                    <XAxis dataKey="date" tickFormatter={(d: string) => d.slice(5)} tick={{ fontSize: 11, fontFamily: 'JetBrains Mono' }} stroke="hsl(198 14% 50%)" />
                    <YAxis allowDecimals={false} tick={{ fontSize: 11, fontFamily: 'JetBrains Mono' }} stroke="hsl(198 14% 50%)" />
                    <Tooltip cursor={{ fill: 'hsl(38 28% 89% / 0.6)' }} contentStyle={{ borderRadius: 6, border: '1px solid hsl(38 20% 84%)', fontSize: 12 }} />
                    <RBar dataKey="visits" name="Visits" fill="hsl(186 58% 28%)" radius={[2, 2, 0, 0]} />
                    <RBar dataKey="people" name="People" fill="hsl(14 80% 56%)" radius={[2, 2, 0, 0]} />
                  </BarChart>
                </ResponsiveContainer>
              </div>
            </section>
            <section className="rise">
              <h2 className="font-display mb-3 text-2xl font-semibold">By service</h2>
              <ul className="space-y-3 rounded-md border border-border bg-card p-5">
                {r.serviceBreakdown.map((s) => (
                  <li key={s.service} data-testid={`text-report-service-${s.service}`}>
                    <div className="mb-1 flex justify-between text-sm"><span>{serviceLabel(s.service)}</span><span className="font-code">{s.visits}</span></div>
                    <div className="h-2 overflow-hidden rounded-full bg-secondary">
                      <div className="h-full origin-left rounded-full transition-transform duration-700" style={{ width: `${(s.visits / maxSvc) * 100}%`, background: SERVICE_TONE[s.service] ?? SERVICE_TONE.other }} />
                    </div>
                  </li>
                ))}
              </ul>
            </section>
          </div>
          <section className="mt-8">
            <h2 className="font-display mb-3 text-2xl font-semibold">By support location</h2>
            <p className="mb-3 text-xs text-muted-foreground">Where support was provided, based on the visit's arrival date. Named sites appear in the CSV and printed report. Review location names before sharing; never record a guest's home or sleeping location here.</p>
            {r.locationBreakdown.length === 0 ? <p className="rounded-md border border-border p-4 text-sm text-muted-foreground">No support locations in this period.</p> : (
              <div className="overflow-x-auto rounded-md border border-border bg-card">
                <table data-testid="table-report-locations" className="w-full text-left text-sm">
                  <thead className="border-b border-border bg-secondary"><tr><th className="p-3">Support location</th><th className="p-3 text-right">Visits</th></tr></thead>
                  <tbody>{r.locationBreakdown.map((item) => <tr key={item.location === null ? 'missing' : `site-${item.location}`} className="border-b border-border last:border-0"><td className="break-words p-3">{item.location ?? 'Not recorded'}</td><td className="font-code p-3 text-right">{item.visits}</td></tr>)}</tbody>
                </table>
              </div>
            )}
          </section>
        </div>
      )}
    </>
  );
}
