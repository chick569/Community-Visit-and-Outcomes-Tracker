import { useEffect, useState } from 'react';
import { Loader2, Plus, Search } from 'lucide-react';
import { useCreateClient, useListClients, type Client } from '@workspace/api-client-react';
import { Bar, EmptyState, ErrorPanel, PageHead } from '@/components/bits';
import { CheckInDialog } from '@/components/check-in-dialog';
import { GuestProfileDialog } from '@/components/guest-profile-dialog';
import { profileRows } from '@/components/guest-profile-fields';
import { GuestQrScan } from '@/components/guest-qr-scan';
import { useToast } from '@/hooks/use-toast';
import { errorMessage, fmtDate, useInvalidateAll } from '@/lib/format';

export default function Guests() {
  const [search, setSearch] = useState('');
  const [debounced, setDebounced] = useState('');
  const [preset, setPreset] = useState<{ id: string; code: string } | null>(null);
  const [fresh, setFresh] = useState<string | null>(null);
  const [profile, setProfile] = useState<Client | null>(null);
  const create = useCreateClient();
  const invalidate = useInvalidateAll();
  const { toast } = useToast();

  useEffect(() => {
    const t = setTimeout(() => setDebounced(search.trim()), 250);
    return () => clearTimeout(t);
  }, [search]);

  const q = useListClients(debounced ? { search: debounced } : undefined);
  const rows = q.data ?? [];

  const newGuest = () =>
    create.mutate(undefined, {
      onSuccess: (c) => { invalidate(); setFresh(c.id); toast({ title: `Code ${c.code} created`, description: 'Hand this code to the guest for future visits.' }); },
      onError: (e) => toast({ title: 'Could not create code', description: errorMessage(e), variant: 'destructive' }),
    });

  return (
    <>
      <PageHead kicker="Directory" title="Guest codes">
        <button data-testid="button-new-guest" disabled={create.isPending} onClick={newGuest} className="inline-flex items-center gap-2 rounded-md bg-primary px-4 py-2 text-sm font-semibold text-primary-foreground transition hover:bg-primary/90 active:scale-[0.98] disabled:opacity-50">
          {create.isPending ? <Loader2 className="h-4 w-4 animate-spin" /> : <Plus className="h-4 w-4" />} Generate new code
        </button>
      </PageHead>

      <p className="rise mb-5 max-w-2xl text-sm text-muted-foreground">
        Use guest codes to find returning guests, or scan a photo of their QR code. Open a profile for optional details, a guest photo, and a printable QR visit summary. Do not infer demographic details.
      </p>

      <div className="mb-5 flex flex-wrap items-start gap-3">
      <div className="relative w-full max-w-md">
        <Search className="absolute left-3 top-1/2 h-4 w-4 -translate-y-1/2 text-muted-foreground" />
        <input data-testid="input-search-guests" value={search} onChange={(e) => setSearch(e.target.value)} maxLength={40} placeholder="Search code" className="font-code w-full rounded-md border border-input bg-card py-2 pl-9 pr-3 text-sm uppercase outline-none focus:ring-2 focus:ring-ring/40" />
      </div>
      <GuestQrScan onCode={setSearch} />
      </div>

      {q.isError ? (
        <ErrorPanel error={q.error} onRetry={() => q.refetch()} />
      ) : q.isLoading ? (
        <div className="grid gap-3 sm:grid-cols-2 lg:grid-cols-4">{[0, 1, 2, 3, 4, 5, 6, 7].map((i) => <Bar key={i} className="h-28" />)}</div>
      ) : rows.length === 0 ? (
        <EmptyState title={debounced ? 'No code matches' : 'No guest codes yet'} body={debounced ? 'Check the characters and try again.' : 'Generate a code the first time someone visits.'} />
      ) : (
        <div className="grid gap-3 sm:grid-cols-2 lg:grid-cols-4">
          {rows.map((c, i) => (
            <div key={c.id} data-testid={`card-guest-${c.id}`} className={`rise group flex flex-col justify-between rounded-md border bg-card p-4 transition hover:-translate-y-0.5 hover:border-foreground/30 ${fresh === c.id ? 'border-[hsl(14_80%_56%)] ring-2 ring-[hsl(14_80%_56%/0.25)]' : 'border-border'}`} style={{ animationDelay: `${Math.min(i, 12) * 30}ms` }}>
              <div className="flex items-start justify-between">
                <span className="font-code text-xl font-semibold tracking-wider">{c.code}</span>
                <span className="font-display text-3xl font-semibold leading-none text-primary">{c.visitCount}</span>
              </div>
              <p data-testid={`text-guest-description-${c.id}`} className="mt-3 text-sm text-muted-foreground">{profileRows(c.demographics).length ? 'Guest profile selections saved' : c.description ? 'Previous description saved' : 'No profile details provided'}</p>
              <button data-testid={`button-guest-profile-${c.id}`} onClick={() => setProfile(c)} className="mt-3 rounded-md border border-border px-3 py-2 text-left text-sm font-medium text-primary hover:bg-secondary">
                Profile &amp; visit summary
              </button>
              <div className="mt-4 flex items-end justify-between text-xs text-muted-foreground">
                <div>
                  <p>Last visit {fmtDate(c.lastVisitAt)}</p>
                  <p>Since {fmtDate(c.createdAt)}</p>
                </div>
                <button data-testid={`button-checkin-${c.id}`} onClick={() => setPreset({ id: c.id, code: c.code })} className="rounded-md border border-border px-2.5 py-1 font-medium text-foreground transition hover:bg-foreground hover:text-background">
                  Check in
                </button>
              </div>
            </div>
          ))}
        </div>
      )}
      <CheckInDialog open={!!preset} onOpenChange={(o) => !o && setPreset(null)} preset={preset} />
      {profile && <GuestProfileDialog key={profile.id} client={profile} onClose={() => setProfile(null)} />}
    </>
  );
}
