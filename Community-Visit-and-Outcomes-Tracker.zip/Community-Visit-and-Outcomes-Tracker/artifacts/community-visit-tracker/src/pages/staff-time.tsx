import { useEffect, useState } from 'react';
import { useQueryClient } from '@tanstack/react-query';
import { Clock3, Loader2, LogIn, LogOut } from 'lucide-react';
import { getGetStaffTimeQueryKey, useGetStaffTime, useClockInStaff, useClockOutStaff } from '@workspace/api-client-react';
import { Bar, EmptyState, ErrorPanel, PageHead } from '@/components/bits';
import { errorMessage, utcMonthStart, utcToday } from '@/lib/format';
import { useToast } from '@/hooks/use-toast';

function stamp(value: string) {
  return new Date(value).toLocaleString([], {
    year: 'numeric', month: 'short', day: 'numeric', hour: '2-digit', minute: '2-digit', second: '2-digit', timeZone: 'UTC',
  });
}

function elapsed(start: string, end: number) {
  const seconds = Math.max(0, Math.floor((end - new Date(start).getTime()) / 1000));
  return [Math.floor(seconds / 3600), Math.floor(seconds / 60) % 60, seconds % 60].map((v) => String(v).padStart(2, '0')).join(':');
}

export default function StaffTime() {
  const [dateFrom, setDateFrom] = useState(utcMonthStart());
  const [dateTo, setDateTo] = useState(utcToday());
  const [now, setNow] = useState(Date.now());
  const [error, setError] = useState<string | null>(null);
  const qc = useQueryClient();
  const { toast } = useToast();
  const params = { dateFrom, dateTo };
  const valid = !!dateFrom && !!dateTo && dateFrom <= dateTo;
  const query = useGetStaffTime(params, {
    query: { queryKey: getGetStaffTimeQueryKey(params), enabled: valid, refetchInterval: 30000 },
  });
  const clockIn = useClockInStaff();
  const clockOut = useClockOutStaff();
  const active = query.data?.currentShift;
  const pending = clockIn.isPending || clockOut.isPending;

  useEffect(() => {
    const timer = setInterval(() => setNow(Date.now()), 1000);
    return () => clearInterval(timer);
  }, []);

  const refresh = () => qc.invalidateQueries({ queryKey: getGetStaffTimeQueryKey() });
  const success = (title: string) => {
    setError(null);
    setNow(Date.now());
    refresh();
    toast({ title });
  };
  const failed = (err: unknown) => {
    setError(errorMessage(err, 'Could not update your shift.'));
    refresh();
  };

  return (
    <>
      <PageHead kicker="Personal time log" title="Staff time" />
      <p className="mb-6 max-w-2xl text-sm text-muted-foreground">Record your own staff time in and out. Each account has a separate time log. Times are saved by the server and displayed in UTC.</p>
      <div className="mb-6 flex flex-wrap items-end gap-3 rounded-md border border-border bg-card p-4">
        <label className="text-sm">From (UTC)<input data-testid="input-shifts-from" type="date" value={dateFrom} onChange={(e) => setDateFrom(e.target.value)} className="mt-1 block rounded-md border border-input bg-background px-3 py-2" /></label>
        <label className="text-sm">To (UTC)<input data-testid="input-shifts-to" type="date" value={dateTo} onChange={(e) => setDateTo(e.target.value)} className="mt-1 block rounded-md border border-input bg-background px-3 py-2" /></label>
        <button data-testid="button-shifts-this-month" onClick={() => { setDateFrom(utcMonthStart()); setDateTo(utcToday()); }} className="rounded-md border border-border px-3 py-2 text-sm">This month</button>
      </div>
      {!valid ? <p role="alert" className="text-sm text-destructive">Choose a valid start and end date.</p> : query.isError ? (
        <ErrorPanel error={query.error} onRetry={() => query.refetch()} />
      ) : query.isLoading || !query.data ? <Bar className="h-48" /> : (
        <>
          <section className="mb-6 grid gap-4 md:grid-cols-2">
            <div className="rounded-md border border-border bg-card p-5">
              <p className="flex items-center gap-2 text-sm font-semibold"><Clock3 className="h-4 w-4 text-primary" /> Your current shift</p>
              <p data-testid="text-staff-clock-status" className="font-display mt-3 text-3xl font-semibold">{active ? 'Clocked in' : 'Off shift'}</p>
              {active ? <p data-testid="text-staff-clock-start" className="mt-2 text-sm text-muted-foreground">Time in: {stamp(active.clockedInAt)} UTC</p> : <p className="mt-2 text-sm text-muted-foreground">Clock in when you begin work.</p>}
              {active && <p data-testid="text-staff-elapsed" className="font-code mt-2 text-xl">{elapsed(active.clockedInAt, now)} <span className="text-xs text-muted-foreground">elapsed (live estimate)</span></p>}
              <button data-testid={active ? 'button-staff-clock-out' : 'button-staff-clock-in'} disabled={pending || query.isFetching} onClick={() => {
                setError(null);
                if (active) clockOut.mutate({ shiftId: active.id }, { onSuccess: () => success('Clocked out — shift saved'), onError: failed });
                else clockIn.mutate(undefined, { onSuccess: () => success('Clocked in'), onError: failed });
              }} className="mt-4 inline-flex items-center gap-2 rounded-md bg-primary px-4 py-2 text-sm font-semibold text-primary-foreground disabled:opacity-50">
                {pending ? <Loader2 className="h-4 w-4 animate-spin" /> : active ? <LogOut className="h-4 w-4" /> : <LogIn className="h-4 w-4" />}
                {active ? 'Time out — end shift' : 'Time in — start shift'}
              </button>
              {error && <p data-testid="text-staff-clock-error" role="alert" className="mt-3 text-sm text-destructive">{error}</p>}
            </div>
            <div className="rounded-md border border-border bg-card p-5">
              <p className="text-sm font-semibold">Completed hours in selected period</p>
              <p data-testid="text-staff-total-hours" className="font-display mt-3 text-4xl font-semibold text-primary">{query.data.completedHours.toFixed(2)} <span className="text-xl">hours</span></p>
              <p data-testid="text-staff-completed-count" className="mt-2 text-sm">{query.data.shifts.filter((s) => s.clockedOutAt).length} completed shifts</p>
              <p className="mt-3 text-xs leading-relaxed text-muted-foreground">Open shifts are excluded from total hours. Shifts are grouped by their time-in date in UTC, including the entire duration if a shift ends on a later date. The current-shift control always shows your active shift, even outside the selected period.</p>
            </div>
          </section>
          <h2 className="font-display mb-3 text-2xl font-semibold">Shift history</h2>
          {query.data.shifts.length === 0 ? <EmptyState title="No shifts in this period" body="Clock in to start your first shift, or choose a different date range." /> : (
            <div className="overflow-x-auto rounded-md border border-border bg-card">
              <table className="w-full text-left text-sm">
                <thead className="border-b border-border bg-secondary"><tr><th className="p-4">Time in (UTC)</th><th className="p-4">Time out (UTC)</th><th className="p-4">Duration</th></tr></thead>
                <tbody>
                  {query.data.shifts.map((shift) => <tr key={shift.id} data-testid={`row-staff-shift-${shift.id}`} className="border-b border-border last:border-0">
                    <td className="whitespace-nowrap p-4">{stamp(shift.clockedInAt)}</td>
                    <td className="whitespace-nowrap p-4">{shift.clockedOutAt ? stamp(shift.clockedOutAt) : 'On shift'}</td>
                    <td className="font-code whitespace-nowrap p-4">{elapsed(shift.clockedInAt, shift.clockedOutAt ? new Date(shift.clockedOutAt).getTime() : now)}{!shift.clockedOutAt && <span className="ml-1 text-xs text-muted-foreground">(live)</span>}</td>
                  </tr>)}
                </tbody>
              </table>
            </div>
          )}
        </>
      )}
    </>
  );
}
