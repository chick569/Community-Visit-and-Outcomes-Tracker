import { Link } from 'wouter';
import { ArrowRight, Clock, FileSpreadsheet, Hash, ShieldCheck } from 'lucide-react';
import { Logo } from '@/components/app-shell';

const SAMPLE = [
  ['08:12', 'K7Q-4M2', 'Meals', 'out 08:51'],
  ['08:40', 'R2D-9XA', 'Hygiene', 'on site'],
  ['09:03', 'B5T-1LP', 'Case management', 'on site'],
  ['09:17', 'K7Q-4M2', 'Outreach', 'on site'],
];

export default function Landing() {
  return (
    <div className="min-h-[100dvh]">
      <header className="mx-auto flex max-w-6xl items-center justify-between px-5 py-5">
        <Logo />
        <div className="flex items-center gap-2 text-sm">
          <Link href="/sign-in" data-testid="link-sign-in" className="rounded-md px-3 py-2 font-medium hover:bg-secondary">Sign in</Link>
          <Link href="/sign-up" data-testid="link-sign-up" className="rounded-md bg-foreground px-4 py-2 font-semibold text-background hover:bg-foreground/90">Start a log</Link>
        </div>
      </header>

      <section className="mx-auto grid max-w-6xl gap-12 px-5 pb-20 pt-10 md:grid-cols-[1.1fr_1fr] md:pt-16">
        <div className="rise">
          <p className="font-code text-xs uppercase tracking-[0.25em] text-primary">For drop-in centers, shelters and outreach teams</p>
          <h1 className="font-display mt-5 text-5xl font-semibold leading-[0.95] tracking-tight md:text-7xl">
            Count every visit.<br /><span className="italic text-[hsl(14_78%_50%)]">Name no one.</span>
          </h1>
          <p className="mt-6 max-w-lg text-lg text-muted-foreground">
            A daily visit log for front-line staff. Check guests in and out under guest codes, then hand funders a clean report of the totals that shows impact without anyone's story in it.
          </p>
          <div className="mt-8 flex flex-wrap gap-3">
            <Link href="/sign-up" data-testid="button-hero-start" className="inline-flex items-center gap-2 rounded-md bg-primary px-5 py-3 font-semibold text-primary-foreground transition hover:bg-primary/90 active:scale-[0.98]">
              Start your log <ArrowRight className="h-4 w-4" />
            </Link>
            <Link href="/sign-in" data-testid="button-hero-signin" className="inline-flex items-center rounded-md border border-foreground/20 px-5 py-3 font-medium hover:bg-secondary">I already have an account</Link>
          </div>
        </div>

        <div className="rise relative" style={{ animationDelay: '120ms' }}>
          <div className="absolute -right-3 -top-3 h-full w-full rounded-md bg-[hsl(14_80%_56%)]" />
          <div className="relative rounded-md border border-foreground/20 bg-card shadow-[0_20px_50px_-20px_hsl(198_42%_14%/0.4)]">
            <div className="flex items-center justify-between border-b border-border bg-[hsl(198_42%_14%)] px-4 py-3 text-[hsl(40_30%_92%)]">
              <span className="font-display text-lg">Tuesday</span>
              <span className="font-code text-xs">3 on site · 4 visits</span>
            </div>
            <ul className="divide-y divide-border">
              {SAMPLE.map(([t, c, s, st]) => (
                <li key={t} className="grid grid-cols-[48px_1fr_auto] items-center gap-3 px-4 py-3 text-sm">
                  <span className="font-code text-xs text-muted-foreground">{t}</span>
                  <span><span className="font-code rounded border border-border px-1.5 py-0.5 text-xs">{c}</span> <span className="ml-2">{s}</span></span>
                  <span className={st === 'on site' ? 'text-xs font-semibold uppercase tracking-wider text-[hsl(14_75%_46%)]' : 'font-code text-xs text-muted-foreground'}>{st}</span>
                </li>
              ))}
            </ul>
          </div>
        </div>
      </section>

      <section className="border-y border-foreground/10 bg-card">
        <div className="mx-auto grid max-w-6xl md:grid-cols-[1fr_1fr_1fr_1fr]">
          {[
            [Hash, 'Codes, not names', 'Each guest gets a generated code. There is nowhere to type a name, phone number or birthday.'],
            [Clock, 'Built for the door', 'Check-in takes two taps. Check-out stamps the time. The board refreshes itself every 30 seconds.'],
            [ShieldCheck, 'Notes with guardrails', 'Every note field reminds staff to keep medical and identifying details out of the record.'],
            [FileSpreadsheet, 'Reports funders read', 'Pick a date range, print it or download a CSV of totals only. No identifiers, ever.'],
          ].map(([Icon, title, body], i) => {
            const I = Icon as typeof Hash;
            return (
              <div key={title as string} className="border-foreground/10 p-7 md:border-l md:first:border-l-0">
                <span className="font-code text-xs text-muted-foreground">0{i + 1}</span>
                <I className="mt-4 h-5 w-5 text-primary" />
                <h3 className="font-display mt-3 text-xl font-semibold">{title as string}</h3>
                <p className="mt-2 text-sm text-muted-foreground">{body as string}</p>
              </div>
            );
          })}
        </div>
      </section>

      <section className="mx-auto max-w-6xl px-5 py-20">
        <div className="grid gap-10 md:grid-cols-2 md:items-center">
          <h2 className="font-display text-4xl font-semibold leading-tight md:text-5xl">
            “1,284 visits from 312 people this quarter.”
          </h2>
          <p className="text-muted-foreground">
            Give your board, city contract and grant renewal a clear summary drawn from your daily log. Records belong to your signed-in account, and stakeholder reports omit guest codes and private notes. This version does not share records between staff accounts.
          </p>
        </div>
      </section>

      <section className="bg-[hsl(198_42%_14%)] text-[hsl(40_30%_94%)]">
        <div className="mx-auto flex max-w-6xl flex-col items-start justify-between gap-6 px-5 py-14 md:flex-row md:items-center">
          <h2 className="font-display text-3xl font-semibold">Open the log before the doors open.</h2>
          <Link href="/sign-up" data-testid="button-footer-start" className="inline-flex items-center gap-2 rounded-md bg-[hsl(14_80%_56%)] px-5 py-3 font-semibold text-white hover:bg-[hsl(14_80%_50%)]">
            Create a free account <ArrowRight className="h-4 w-4" />
          </Link>
        </div>
      </section>
      <footer className="font-code mx-auto max-w-6xl px-5 py-6 text-xs text-muted-foreground">Mercy Holisitic Connect · coded visit records for community services</footer>
    </div>
  );
}
