import { useEffect, useState } from 'react';
import { useQueryClient } from '@tanstack/react-query';
import { Eye, Loader2, ShieldCheck, ShieldOff, TriangleAlert } from 'lucide-react';
import {
  getGetPrivacySettingsQueryKey, useGetPrivacySettings, usePreviewPrivacyRetention, useSavePrivacySettings,
  type RetentionPreview,
} from '@workspace/api-client-react';
import { Bar, ErrorPanel, GuestCode, PageHead } from '@/components/bits';
import { errorMessage, useInvalidateAll } from '@/lib/format';
import { useToast } from '@/hooks/use-toast';

function when(iso: string) {
  return new Date(iso).toLocaleString([], { year: 'numeric', month: 'short', day: 'numeric', hour: '2-digit', minute: '2-digit', timeZone: 'UTC' }) + ' UTC';
}

function parseDays(raw: string): number | null {
  if (!/^\d+$/.test(raw.trim())) return null;
  const n = Number(raw);
  return n >= 1 && n <= 3650 ? n : null;
}

function Flag({ on, label }: { on: boolean; label: string }) {
  return <span className={on ? 'rounded bg-[hsl(14_80%_56%/0.15)] px-1.5 py-0.5 text-[11px] font-medium text-[hsl(14_70%_38%)]' : 'px-1.5 py-0.5 text-[11px] text-muted-foreground/60 line-through'}>{label}</span>;
}

export default function Privacy() {
  const qc = useQueryClient();
  const invalidate = useInvalidateAll();
  const { toast } = useToast();
  const query = useGetPrivacySettings({ query: { queryKey: getGetPrivacySettingsQueryKey(), refetchOnMount: 'always', refetchInterval: 30000 } });
  const save = useSavePrivacySettings();
  const previewM = usePreviewPrivacyRetention();
  const [raw, setRaw] = useState('');
  const [preview, setPreview] = useState<{ days: number; data: RetentionPreview } | null>(null);
  const [confirmed, setConfirmed] = useState(false);
  const [error, setError] = useState<string | null>(null);
  const current = query.data?.retentionDays ?? null;

  useEffect(() => {
    if (query.data && raw === '') setRaw(String(query.data.retentionDays ?? 90));
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [query.data]);

  const days = parseDays(raw);
  const validPreview = preview && days === preview.days ? preview.data : null;
  const busy = save.isPending || previewM.isPending;

  const changeDays = (v: string) => { setRaw(v); setPreview(null); setConfirmed(false); setError(null); };

  const runPreview = () => {
    if (days == null) return;
    setError(null); setConfirmed(false);
    previewM.mutate({ data: { retentionDays: days } }, {
      onSuccess: (data) => setPreview({ days, data }),
      onError: (err) => setError(errorMessage(err, 'Could not prepare the preview.')),
    });
  };

  const afterSave = (msg: string) => (saved: { retentionDays: number | null }) => {
    qc.setQueryData(getGetPrivacySettingsQueryKey(), saved);
    qc.invalidateQueries({ queryKey: getGetPrivacySettingsQueryKey() });
    invalidate();
    setPreview(null); setConfirmed(false);
    toast({ title: msg });
  };

  const enable = () => {
    if (!validPreview || !confirmed || days == null) return;
    setError(null);
    save.mutate({ data: { retentionDays: days, previewToken: validPreview.previewToken, confirmed: true } }, {
      onSuccess: afterSave(`Automatic removal set to ${days} days`),
      onError: (err) => {
        const status = (err as { status?: number }).status;
        setPreview(null); setConfirmed(false);
        if (status === 409) {
          setError('The preview is out of date — records changed or it expired. Preparing a fresh preview; review it and confirm again.');
          runPreview();
        } else setError(errorMessage(err, 'Could not save the setting.'));
      },
    });
  };

  const disable = () => {
    setError(null);
    save.mutate({ data: { retentionDays: null } }, {
      onSuccess: afterSave('Automatic removal turned off'),
      onError: (err) => setError(errorMessage(err, 'Could not turn off automatic removal.')),
    });
  };

  const records = validPreview?.records ?? [];

  return (
    <div className="space-y-8">
      <PageHead kicker="Settings · Privacy" title="Sensitive detail removal" />

      {query.isError ? <ErrorPanel error={query.error} onRetry={() => query.refetch()} /> : query.isLoading ? (
        <div className="space-y-3"><Bar className="h-20" /><Bar className="h-40" /></div>
      ) : (
        <div className="grid gap-8 lg:grid-cols-[1fr_1.3fr]">
          <section className="rise space-y-5">
            <div data-testid="status-retention" className={`rounded-md border p-5 ${current == null ? 'border-border bg-card' : 'border-primary/40 bg-primary/5'}`}>
              <p className="font-code text-[11px] uppercase tracking-[0.2em] text-muted-foreground">Current setting {query.isFetching && <Loader2 className="ml-1 inline h-3 w-3 animate-spin" />}</p>
              <p className="font-display mt-2 text-3xl font-semibold" data-testid="text-retention-current">
                {current == null ? 'Off' : `${current} days`}
              </p>
              <p className="mt-1 text-sm text-muted-foreground">{current == null ? 'Guest profile details are kept until staff remove them.' : 'Details older than this are removed automatically.'}</p>
              {current != null && (
                <button data-testid="button-disable-retention" disabled={busy} onClick={disable} className="mt-4 inline-flex items-center gap-2 rounded-md border border-border bg-card px-3 py-2 text-sm font-medium disabled:opacity-50">
                  {save.isPending ? <Loader2 className="h-4 w-4 animate-spin" /> : <ShieldOff className="h-4 w-4" />} Disable automatic removal
                </button>
              )}
            </div>
            <div className="space-y-3 text-sm leading-relaxed text-foreground/85">
              <h2 className="font-display text-xl font-semibold">What this does</h2>
              <p>When enabled, demographic selections and any previous text description are permanently removed from a guest profile once it has gone the chosen number of days without a profile edit. Older records without an edit date use the guest's creation date.</p>
              <p>Removal runs immediately when you enable it, then hourly while the server is running. It cannot be undone.</p>
              <p className="rounded-md bg-secondary p-3 text-xs">Untouched: visits, guest codes, services, staff shifts and report totals.</p>
            </div>
          </section>

          <section className="rise space-y-5 rounded-md border border-border bg-card p-5">
            <div className="flex flex-wrap items-end gap-3">
              <label className="flex-1 text-sm font-medium">Remove details older than (days)
                <input data-testid="input-retention-days" type="number" min={1} max={3650} step={1} value={raw} disabled={busy} onChange={(e) => changeDays(e.target.value)} className="mt-1 block w-full rounded-md border border-border bg-background px-3 py-2 font-code" />
              </label>
              <button data-testid="button-preview-retention" disabled={days == null || busy} onClick={runPreview} className="inline-flex items-center gap-2 rounded-md border border-border px-3 py-2 text-sm font-medium disabled:opacity-50">
                {previewM.isPending ? <Loader2 className="h-4 w-4 animate-spin" /> : <Eye className="h-4 w-4" />} Preview affected guests
              </button>
            </div>
            {raw !== '' && days == null && <p className="text-xs text-destructive" data-testid="text-days-invalid">Enter a whole number from 1 to 3650.</p>}
            {error && <p role="alert" data-testid="text-privacy-error" className="rounded-md bg-destructive/10 p-3 text-sm text-destructive">{error}</p>}

            {previewM.isPending ? <Bar className="h-32" /> : validPreview ? (
              <div className="space-y-4" data-testid="panel-retention-preview">
                <dl className="grid grid-cols-3 gap-3 text-sm">
                  <div><dt className="text-xs text-muted-foreground">Affected now</dt><dd className="font-display text-2xl font-semibold" data-testid="text-preview-count">{records.length}</dd></div>
                  <div><dt className="text-xs text-muted-foreground">Last edit before</dt><dd className="font-code text-xs" data-testid="text-preview-cutoff">{when(validPreview.cutoff)}</dd></div>
                  <div><dt className="text-xs text-muted-foreground">Preview expires</dt><dd className="font-code text-xs" data-testid="text-preview-expires">{when(validPreview.expiresAt)}</dd></div>
                </dl>
                {records.length === 0 ? (
                  <p className="rounded-md border border-dashed border-border p-4 text-sm text-muted-foreground">No guest profiles would be changed right now.</p>
                ) : (
                  <ul className="max-h-72 divide-y divide-border overflow-y-auto rounded-md border border-border" data-testid="list-preview-records">
                    {records.map((r) => (
                      <li key={r.code} className="flex items-center justify-between gap-2 px-3 py-2" data-testid={`row-preview-${r.code}`}>
                        <GuestCode code={r.code} />
                        <span className="flex gap-1"><Flag on={r.hasDemographics} label="demographics" /><Flag on={r.hasDescription} label="description" /></span>
                      </li>
                    ))}
                  </ul>
                )}
                <label className="flex items-start gap-2 rounded-md border border-[hsl(14_80%_56%/0.4)] bg-[hsl(14_80%_56%/0.06)] p-3 text-sm">
                  <input data-testid="checkbox-confirm-retention" type="checkbox" checked={confirmed} onChange={(e) => setConfirmed(e.target.checked)} className="mt-1" />
                  <span><TriangleAlert className="mr-1 inline h-3.5 w-3.5 text-[hsl(14_70%_44%)]" />I understand the details listed above will be permanently removed now, and more will be removed hourly as profiles age past {days} days.</span>
                </label>
                <button data-testid="button-enable-retention" disabled={!confirmed || busy} onClick={enable} className="inline-flex items-center gap-2 rounded-md bg-primary px-4 py-2 text-sm font-semibold text-primary-foreground disabled:opacity-50">
                  {save.isPending ? <Loader2 className="h-4 w-4 animate-spin" /> : <ShieldCheck className="h-4 w-4" />} Enable removal after {days} days
                </button>
              </div>
            ) : (
              <p className="text-sm text-muted-foreground">Preview which guest codes would be affected before enabling. Changing the number of days requires a new preview.</p>
            )}
          </section>
        </div>
      )}
    </div>
  );
}
