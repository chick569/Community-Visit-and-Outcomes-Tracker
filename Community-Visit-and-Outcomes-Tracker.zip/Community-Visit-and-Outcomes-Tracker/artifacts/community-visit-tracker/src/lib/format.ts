import { useQueryClient } from '@tanstack/react-query';
import {
  getGetDashboardQueryKey,
  getGetReportQueryKey,
  getListClientsQueryKey,
  getListVisitsQueryKey,
  getListSupportLocationsQueryKey,
} from '@workspace/api-client-react';

export const SERVICES = [
  { value: 'shelter', label: 'Shelter' },
  { value: 'meals', label: 'Meals' },
  { value: 'hygiene', label: 'Hygiene' },
  { value: 'case-management', label: 'Case management' },
  { value: 'outreach', label: 'Outreach' },
  { value: 'other', label: 'Other' },
] as const;

export type ServiceValue = (typeof SERVICES)[number]['value'];

export const OUTCOMES = [
  { value: 'connected-to-services', label: 'Connected to services' },
  { value: 'return-planned', label: 'Return planned' },
  { value: 'other', label: 'Other' },
] as const;

export type OutcomeValue = (typeof OUTCOMES)[number]['value'];

export const SERVICE_TONE: Record<string, string> = {
  shelter: 'hsl(186 58% 28%)',
  meals: 'hsl(14 80% 56%)',
  hygiene: 'hsl(42 78% 50%)',
  'case-management': 'hsl(198 40% 42%)',
  outreach: 'hsl(150 30% 40%)',
  other: 'hsl(198 12% 58%)',
};

export function serviceLabel(v: string) {
  return SERVICES.find((s) => s.value === v)?.label ?? v;
}
export function outcomeLabel(v: string | null | undefined) {
  if (!v) return null;
  return OUTCOMES.find((s) => s.value === v)?.label ?? v;
}

export function fmtTime(iso: string | null | undefined) {
  if (!iso) return '—';
  return new Date(iso).toLocaleTimeString([], { hour: 'numeric', minute: '2-digit' });
}
export function fmtDate(iso: string | null | undefined) {
  if (!iso) return '—';
  return new Date(iso).toLocaleDateString([], { month: 'short', day: 'numeric', year: 'numeric' });
}
export function fmtDay(iso: string) {
  return new Date(iso).toLocaleDateString([], { weekday: 'short', month: 'short', day: 'numeric' });
}
export function duration(from: string, to: string | null) {
  const ms = (to ? new Date(to).getTime() : Date.now()) - new Date(from).getTime();
  const m = Math.max(0, Math.round(ms / 60000));
  if (m < 60) return `${m}m`;
  return `${Math.floor(m / 60)}h ${m % 60}m`;
}

export function utcToday() {
  return new Date().toISOString().slice(0, 10);
}
export function utcMonthStart() {
  const d = new Date();
  return new Date(Date.UTC(d.getUTCFullYear(), d.getUTCMonth(), 1)).toISOString().slice(0, 10);
}
export function utcDaysAgo(n: number) {
  return new Date(Date.now() - n * 86400000).toISOString().slice(0, 10);
}

export function errorMessage(err: unknown, fallback = 'Something went wrong.') {
  if (!err) return fallback;
  const e = err as { status?: number; data?: unknown; message?: string };
  const data = e.data as { error?: string } | null | undefined;
  if (data && typeof data === 'object' && typeof data.error === 'string') return data.error;
  if (e.status === 409) return 'This guest already has an open visit. Record their departure before checking them in again.';
  return e.message || fallback;
}

export function useInvalidateAll() {
  const qc = useQueryClient();
  return () => {
    qc.invalidateQueries({ queryKey: getListVisitsQueryKey() });
    qc.invalidateQueries({ queryKey: getListSupportLocationsQueryKey() });
    qc.invalidateQueries({ queryKey: getListClientsQueryKey() });
    qc.invalidateQueries({ predicate: ({ queryKey }) => typeof queryKey[0] === 'string' && queryKey[0].startsWith('/api/clients/') });
    qc.invalidateQueries({ queryKey: getGetDashboardQueryKey() });
    qc.invalidateQueries({ queryKey: getGetReportQueryKey() });
  };
}
