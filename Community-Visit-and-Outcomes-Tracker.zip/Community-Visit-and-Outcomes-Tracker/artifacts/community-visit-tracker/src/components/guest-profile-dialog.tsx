import { useEffect, useState } from 'react';
import { createPortal } from 'react-dom';
import { useForm } from 'react-hook-form';
import { useQueryClient } from '@tanstack/react-query';
import { ArrowLeft, FileText, Loader2, Printer, Save, Trash2 } from 'lucide-react';
import {
  getGetClientSummaryQueryKey, useGetClientSummary, useUpdateClient, useRemoveClientDescription,
  type Client, type GuestSummary, type GuestDemographics,
} from '@workspace/api-client-react';
import { Dialog, DialogContent, DialogDescription, DialogHeader, DialogTitle } from '@/components/ui/dialog';
import { Form } from '@/components/ui/form';
import { GuestProfileFields, profileDefaults, profileRows } from '@/components/guest-profile-fields';
import { GuestPhoto } from '@/components/guest-photo';
import { GuestQrCode } from '@/components/guest-qr-code';
import { Bar, ErrorPanel } from '@/components/bits';
import { errorMessage, serviceLabel, useInvalidateAll } from '@/lib/format';
import { useToast } from '@/hooks/use-toast';

function fullDate(value: string) {
  return new Date(value).toLocaleString([], {
    year: 'numeric', month: 'short', day: 'numeric',
    hour: '2-digit', minute: '2-digit', timeZone: 'UTC',
  });
}

function Handout({ summary, includeProfile }: { summary: GuestSummary; includeProfile: boolean }) {
  return (
    <article className="guest-handout" data-testid="guest-handout-preview">
      <p className="font-code text-xs uppercase tracking-wider">Mercy Holisitic Connect · Guest copy</p>
      <h2 className="font-display mt-2 text-3xl font-semibold">Your visit summary</h2>
      <p className="mt-3 text-sm">Guest code: <strong className="font-code">{summary.client.code}</strong></p>
      <p className="mt-1 text-sm">Prepared {fullDate(new Date().toISOString())} UTC</p>
      <p className="mt-3 text-sm">Keep your code to help staff find your record when you return.</p>
      <div className="my-4 flex flex-wrap items-center gap-4">
        <GuestQrCode code={summary.client.code} />
        <p className="max-w-xs text-xs text-muted-foreground">This QR code contains only your guest code. Staff can use it to find your record when you return. It does not contain your photo or personal details.</p>
      </div>
      {includeProfile && (profileRows(summary.client.demographics).length > 0 || summary.client.description) && (
        <section className="my-5 rounded-md border border-border p-4" data-testid="handout-description">
          <h3 className="font-semibold">Guest profile</h3>
          <dl className="mt-2 space-y-2 text-sm" data-testid="handout-demographics">
            {profileRows(summary.client.demographics).map(([label, value]) => <div key={label} className="break-words"><dt className="font-semibold">{label}</dt><dd>{value}</dd></div>)}
          </dl>
          {summary.client.description && <div className="mt-3"><h4 className="text-sm font-semibold">Previous description</h4><p className="mt-1 whitespace-pre-wrap break-words text-sm">{summary.client.description}</p></div>}
        </section>
      )}
      <h3 className="mt-6 mb-3 font-semibold">Recorded visits ({summary.visits.length})</h3>
      {summary.visits.length === 0 ? (
        <p className="text-sm">No visits have been recorded yet.</p>
      ) : (
        <div className="overflow-x-auto">
          <table className="w-full border-collapse text-left text-sm">
            <thead>
              <tr className="border-b-2 border-border">
                <th className="py-2 pr-3">Service</th>
                <th className="py-2 pr-3">Support location</th>
                <th className="py-2 pr-3">Arrival (UTC)</th>
                <th className="py-2">Departure (UTC)</th>
              </tr>
            </thead>
            <tbody>
              {summary.visits.map((visit) => (
                <tr key={visit.id} className="border-b border-border">
                  <td className="py-3 pr-3">{serviceLabel(visit.service)}</td>
                  <td className="max-w-[200px] break-words py-3 pr-3">{visit.location || 'Not recorded'}</td>
                  <td className="py-3 pr-3">{fullDate(visit.arrivedAt)}</td>
                  <td className="py-3">{visit.departedAt ? fullDate(visit.departedAt) : 'Not checked out'}</td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>
      )}
      <p className="mt-6 text-xs leading-relaxed">All times are UTC. This is a record of logged visits and services, not proof of housing or eligibility. Staff visit notes and internal outcomes are not included.</p>
    </article>
  );
}

export function GuestProfileDialog({ client, onClose }: { client: Client; onClose: () => void }) {
  const [preview, setPreview] = useState(false);
  const [includeProfile, setIncludeProfile] = useState(false);
  const [error, setError] = useState<string | null>(null);
  const [photoBusy, setPhotoBusy] = useState(false);
  const form = useForm<GuestDemographics>({ defaultValues: profileDefaults(client.demographics) });
  const query = useGetClientSummary(client.id, {
    query: { queryKey: getGetClientSummaryQueryKey(client.id), refetchInterval: 30000 },
  });
  const update = useUpdateClient();
  const removeDesc = useRemoveClientDescription();
  const [descRemoved, setDescRemoved] = useState(false);
  const qc = useQueryClient();
  const invalidate = useInvalidateAll();
  const { toast } = useToast();
  const summary = query.data;
  const dirty = form.formState.isDirty;
  const previousNationality = summary ? summary.client.demographics.nationality : client.demographics.nationality;

  useEffect(() => {
    // Refresh untouched fields from the current profile without replacing an in-progress edit.
    if (summary && !dirty && !update.isPending && JSON.stringify(form.getValues()) !== JSON.stringify(profileDefaults(summary.client.demographics))) {
      form.reset(profileDefaults(summary.client.demographics));
    }
  }, [summary, dirty, update.isPending, form]);

  const close = () => {
    if (update.isPending || photoBusy || removeDesc.isPending) return;
    if (dirty && !window.confirm('Discard the unsaved guest profile selections?')) return;
    onClose();
  };

  const save = form.handleSubmit((demographics) => {
    setError(null);
    update.mutate({ clientId: client.id, data: { demographics } }, {
      onSuccess: (saved) => {
        form.reset(profileDefaults(saved.demographics));
        qc.setQueryData<GuestSummary>(getGetClientSummaryQueryKey(client.id), (old) => old ? { ...old, client: saved } : old);
        invalidate();
        toast({ title: profileRows(saved.demographics).length ? 'Guest profile saved' : 'Guest profile selections cleared', description: saved.code });
      },
      onError: (err) => setError(errorMessage(err, 'Could not save this guest profile.')),
    });
  });

  const description = descRemoved ? null : summary ? summary.client.description : client.description;
  const removeDescription = () => {
    if (!window.confirm('Permanently remove the previous text description for this guest? Demographic selections, photo and visits are kept. This cannot be undone.')) return;
    setError(null);
    removeDesc.mutate({ clientId: client.id, data: { confirmed: true } }, {
      onSuccess: () => {
        setDescRemoved(true);
        qc.setQueryData<GuestSummary>(getGetClientSummaryQueryKey(client.id), (old) => old ? { ...old, client: { ...old.client, description: null } } : old);
        invalidate();
        toast({ title: 'Previous description removed', description: client.code });
      },
      onError: (err) => setError(errorMessage(err, 'Could not remove the previous description.')),
    });
  };

  return (
    <>
      <Dialog open onOpenChange={(open) => !open && close()}>
        <DialogContent className="max-h-[92dvh] max-w-3xl overflow-y-auto bg-card">
          <DialogHeader>
            <DialogTitle className="font-display text-2xl">Guest {client.code}</DialogTitle>
            <DialogDescription>
              {preview ? 'Review exactly what will appear on the guest handout before printing.' : 'Select only the details the guest chooses to share. Every field can be skipped.'}
            </DialogDescription>
          </DialogHeader>
          {preview && summary ? (
            <>
              <div className="flex flex-wrap items-center justify-between gap-3">
                <button data-testid="button-back-guest-profile" onClick={() => setPreview(false)} className="inline-flex items-center gap-2 rounded-md border border-border px-3 py-2 text-sm">
                  <ArrowLeft className="h-4 w-4" /> Back to profile
                </button>
                <button data-testid="button-print-guest-summary" onClick={() => window.print()} className="inline-flex items-center gap-2 rounded-md bg-primary px-4 py-2 text-sm font-semibold text-primary-foreground">
                  <Printer className="h-4 w-4" /> Print / Save as PDF
                </button>
              </div>
              <label className="flex items-start gap-2 rounded-md border border-border p-3 text-sm">
                <input data-testid="checkbox-include-profile" type="checkbox" checked={includeProfile} disabled={!summary.client.description && !profileRows(summary.client.demographics).length} onChange={(e) => setIncludeProfile(e.target.checked)} className="mt-1" />
                <span>Include the saved guest profile and any previous description
                  <span className="block text-xs text-muted-foreground">This adds sensitive demographic selections. Only include these with the guest's agreement. Staff visit notes are never printed.</span>
                </span>
              </label>
              <div className="rounded-md border border-border bg-background p-5">
                <Handout summary={summary} includeProfile={includeProfile} />
              </div>
            </>
          ) : (
            <>
              <div className="grid gap-5 rounded-md border border-border p-4 sm:grid-cols-[1fr_180px]">
                {summary ? <GuestPhoto clientId={client.id} updatedAt={summary.client.photoUpdatedAt} onBusy={setPhotoBusy} onChanged={(photoUpdatedAt) => {
                  qc.setQueryData<GuestSummary>(getGetClientSummaryQueryKey(client.id), (old) => old ? { ...old, client: { ...old.client, photoUpdatedAt } } : old);
                  invalidate();
                }} /> : <Bar className="h-36" />}
                <section className="space-y-2">
                  <h3 className="text-sm font-semibold text-center">Guest QR code</h3>
                  <GuestQrCode code={client.code} downloadable />
                  <p className="text-center text-xs text-muted-foreground">Contains the guest code only. Staff still need to sign in to view records.</p>
                </section>
              </div>
              <Form {...form}>
                <form onSubmit={save} className="space-y-4">
                  <GuestProfileFields form={form} />
                  {previousNationality && <details data-testid="legacy-nationality" className="rounded-md border border-border p-3 text-sm"><summary className="cursor-pointer font-semibold">Previous nationality response (preserved separately)</summary><p className="mt-2 break-words">{previousNationality}</p><p className="mt-1 text-xs text-muted-foreground">This earlier response has not been converted to ethnicity.</p></details>}
                  {description && <details data-testid="legacy-description" className="rounded-md border border-border p-3 text-sm"><summary className="cursor-pointer font-semibold">Previous text description (preserved)</summary><p className="mt-2 whitespace-pre-wrap break-words text-muted-foreground">{description}</p><button type="button" data-testid="button-remove-description" disabled={removeDesc.isPending || update.isPending || photoBusy} onClick={removeDescription} className="mt-3 inline-flex items-center gap-2 rounded-md border border-destructive/30 px-3 py-2 text-sm text-destructive disabled:opacity-50">{removeDesc.isPending ? <Loader2 className="h-4 w-4 animate-spin" /> : <Trash2 className="h-4 w-4" />} Remove previous description</button></details>}
                  {error && <p role="alert" data-testid="text-description-error" className="rounded-md bg-destructive/10 p-3 text-sm text-destructive">{error}</p>}
                  <div className="flex flex-wrap items-center justify-between gap-3 border-t border-border pt-4">
                    <p className="text-xs text-muted-foreground">{dirty ? 'Unsaved changes — save before preparing a handout.' : 'Selections are optional. No response is assumed.'}</p>
                    <div className="flex gap-2">
                      <button data-testid="button-clear-guest-profile" type="button" disabled={update.isPending || photoBusy} onClick={() => form.reset({ ...profileDefaults(), nationality: previousNationality ?? null }, { keepDefaultValues: true })} className="rounded-md border border-border px-3 py-2 text-sm disabled:opacity-50">Clear selections</button>
                      <button data-testid="button-save-guest-profile" type="submit" disabled={update.isPending || photoBusy || !dirty} className="inline-flex items-center gap-2 rounded-md bg-primary px-4 py-2 text-sm font-semibold text-primary-foreground disabled:opacity-50">
                        {update.isPending ? <Loader2 className="h-4 w-4 animate-spin" /> : <Save className="h-4 w-4" />} Save profile
                      </button>
                    </div>
                  </div>
                </form>
              </Form>
              {query.isError ? <ErrorPanel error={query.error} onRetry={() => query.refetch()} /> : query.isLoading ? <Bar className="h-12" /> : summary && (
                <div className="mt-2 flex flex-wrap items-center justify-between gap-3 rounded-md border border-border p-4">
                  <div>
                    <h3 className="font-semibold">Guest visit summary</h3>
                    <p className="text-sm text-muted-foreground" data-testid="text-guest-summary-count">{summary.visits.length} recorded visits · staff notes excluded</p>
                  </div>
                  <button data-testid="button-preview-guest-summary" disabled={dirty || update.isPending || photoBusy || query.isFetching} onClick={() => { setIncludeProfile(false); setPreview(true); }} className="inline-flex items-center gap-2 rounded-md border border-border px-3 py-2 text-sm font-medium disabled:opacity-50">
                    <FileText className="h-4 w-4" /> Preview handout
                  </button>
                </div>
              )}
            </>
          )}
        </DialogContent>
      </Dialog>
      {preview && summary && createPortal(
        <div id="guest-summary-print" aria-hidden="true">
          <Handout summary={summary} includeProfile={includeProfile} />
        </div>,
        document.body,
      )}
    </>
  );
}
