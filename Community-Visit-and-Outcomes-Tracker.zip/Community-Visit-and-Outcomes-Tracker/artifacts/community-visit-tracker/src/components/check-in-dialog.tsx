import { useEffect, useState } from 'react';
import { Loader2, Plus, Search } from 'lucide-react';
import { useCreateClient, useCreateVisit, useListClients } from '@workspace/api-client-react';
import { Dialog, DialogContent, DialogDescription, DialogHeader, DialogTitle } from '@/components/ui/dialog';
import { useToast } from '@/hooks/use-toast';
import { GuestCode, PrivacyNote } from '@/components/bits';
import { OUTCOMES, SERVICES, SERVICE_TONE, errorMessage, fmtDate, useInvalidateAll, type OutcomeValue, type ServiceValue } from '@/lib/format';
import { cn } from '@/lib/utils';
import { SupportLocationField } from '@/components/support-location-field';

type Props = {
  open: boolean;
  onOpenChange: (o: boolean) => void;
  preset?: { id: string; code: string } | null;
};

export function CheckInDialog({ open, onOpenChange, preset }: Props) {
  const [mode, setMode] = useState<'existing' | 'new'>('existing');
  const [search, setSearch] = useState('');
  const [debounced, setDebounced] = useState('');
  const [guest, setGuest] = useState<{ id: string; code: string } | null>(null);
  const [service, setService] = useState<ServiceValue>('meals');
  const [outcome, setOutcome] = useState<OutcomeValue | ''>('');
  const [notes, setNotes] = useState('');
  const [location, setLocation] = useState('');
  const [err, setErr] = useState<string | null>(null);
  const { toast } = useToast();
  const invalidate = useInvalidateAll();

  useEffect(() => {
    if (open) {
      setMode('existing');
      setSearch('');
      setDebounced('');
      setGuest(preset ?? null);
      setService('meals');
      setOutcome('');
      setNotes('');
      setLocation('');
      setErr(null);
    }
  }, [open, preset]);

  useEffect(() => {
    const t = setTimeout(() => setDebounced(search.trim()), 250);
    return () => clearTimeout(t);
  }, [search]);

  const clients = useListClients(debounced ? { search: debounced } : undefined);
  const createClient = useCreateClient();
  const createVisit = useCreateVisit();
  const pending = createClient.isPending || createVisit.isPending;

  const submit = async () => {
    setErr(null);
    try {
      let target = guest;
      if (mode === 'new') {
        const c = await createClient.mutateAsync();
        target = { id: c.id, code: c.code };
      }
      if (!target) {
        setErr('Choose a guest code first.');
        return;
      }
      const v = await createVisit.mutateAsync({
        data: {
          clientId: target.id,
          service,
          location: location.trim() || null,
          ...(notes.trim() ? { notes: notes.trim() } : {}),
          ...(outcome ? { outcome } : {}),
        },
      });
      invalidate();
      toast({ title: `${v.clientCode} checked in`, description: 'Visit is now open on the board.' });
      onOpenChange(false);
    } catch (e) {
      invalidate();
      setErr(errorMessage(e, 'Check-in failed.'));
    }
  };

  const list = clients.data ?? [];

  return (
    <Dialog open={open} onOpenChange={onOpenChange}>
      <DialogContent className="max-h-[92dvh] max-w-lg overflow-y-auto border-foreground/15 bg-card p-0">
        <div className="border-b border-border bg-[hsl(198_42%_14%)] px-6 py-5 text-[hsl(40_30%_94%)]">
          <DialogHeader>
            <p className="font-code text-[10px] uppercase tracking-[0.25em] text-[hsl(14_80%_66%)]">New entry</p>
            <DialogTitle className="font-display text-3xl font-semibold">Check in a guest</DialogTitle>
            <DialogDescription className="text-[hsl(40_20%_78%)]">Arrival time is stamped automatically.</DialogDescription>
          </DialogHeader>
        </div>

        <div className="space-y-5 px-6 py-5">
          {!preset && (
            <div className="grid grid-cols-2 gap-1 rounded-md bg-secondary p-1 text-sm font-medium">
              {(['existing', 'new'] as const).map((m) => (
                <button
                  key={m}
                  data-testid={`tab-${m}-guest`}
                  onClick={() => setMode(m)}
                  className={cn('rounded px-3 py-1.5 transition', mode === m ? 'bg-card shadow-sm' : 'text-muted-foreground hover:text-foreground')}
                >
                  {m === 'existing' ? 'Returning guest' : 'New guest code'}
                </button>
              ))}
            </div>
          )}

          {preset ? (
            <div className="flex items-center justify-between rounded-md border border-border p-3 text-sm">
              <span className="text-muted-foreground">Guest</span>
              <GuestCode code={preset.code} />
            </div>
          ) : mode === 'existing' ? (
            <div>
              <div className="relative">
                <Search className="absolute left-3 top-1/2 h-4 w-4 -translate-y-1/2 text-muted-foreground" />
                <input
                  data-testid="input-guest-search"
                  autoFocus
                  value={search}
                  onChange={(e) => setSearch(e.target.value)}
                  maxLength={40}
                  placeholder="Search guest code"
                  className="font-code w-full rounded-md border border-input bg-background py-2 pl-9 pr-3 text-sm uppercase outline-none focus:ring-2 focus:ring-ring/40"
                />
              </div>
              <div className="mt-2 max-h-48 overflow-y-auto rounded-md border border-border">
                {clients.isLoading ? (
                  <div className="space-y-2 p-3">{[0, 1, 2].map((i) => <div key={i} className="h-7 animate-pulse rounded bg-foreground/[0.06]" />)}</div>
                ) : clients.isError ? (
                  <p className="p-3 text-sm text-destructive">{errorMessage(clients.error)}</p>
                ) : list.length === 0 ? (
                  <p className="p-4 text-center text-sm text-muted-foreground">No matching codes. Switch to “New guest code”.</p>
                ) : (
                  list.map((c) => (
                    <button
                      key={c.id}
                      data-testid={`option-guest-${c.id}`}
                      onClick={() => setGuest({ id: c.id, code: c.code })}
                      className={cn(
                        'flex w-full items-center justify-between border-b border-border px-3 py-2 text-left text-sm last:border-0 transition',
                        guest?.id === c.id ? 'bg-primary/10' : 'hover:bg-secondary',
                      )}
                    >
                      <GuestCode code={c.code} className={guest?.id === c.id ? 'border-primary' : ''} />
                      <span className="text-xs text-muted-foreground">
                        {c.visitCount} visits · last {fmtDate(c.lastVisitAt)}
                      </span>
                    </button>
                  ))
                )}
              </div>
            </div>
          ) : (
            <div className="rounded-md border border-dashed border-primary/40 bg-primary/5 p-4 text-sm">
              A new anonymous code will be generated. Write it on the guest's card so they can share it next visit.
            </div>
          )}

          <div>
            <p className="mb-2 text-xs font-semibold uppercase tracking-wider text-muted-foreground">Service</p>
            <div className="grid grid-cols-2 gap-2 sm:grid-cols-3">
              {SERVICES.map((s) => (
                <button
                  key={s.value}
                  data-testid={`button-service-${s.value}`}
                  onClick={() => setService(s.value)}
                  className={cn(
                    'flex items-center gap-2 rounded-md border px-3 py-2 text-left text-sm transition active:scale-[0.97]',
                    service === s.value ? 'border-foreground bg-foreground text-background' : 'border-border hover:border-foreground/40',
                  )}
                >
                  <span className="h-2 w-2 rounded-[2px]" style={{ background: SERVICE_TONE[s.value] }} />
                  {s.label}
                </button>
              ))}
            </div>
          </div>

          <SupportLocationField value={location} onChange={setLocation} enabled={open} />
          <div>
            <p className="mb-2 text-xs font-semibold uppercase tracking-wider text-muted-foreground">Outcome (optional)</p>
            <select
              data-testid="select-outcome"
              value={outcome}
              onChange={(e) => setOutcome(e.target.value as OutcomeValue | '')}
              className="w-full rounded-md border border-input bg-background px-3 py-2 text-sm"
            >
              <option value="">Not yet known</option>
              {OUTCOMES.map((o) => <option key={o.value} value={o.value}>{o.label}</option>)}
            </select>
          </div>

          <div>
            <p className="mb-2 text-xs font-semibold uppercase tracking-wider text-muted-foreground">Notes (optional)</p>
            <textarea
              data-testid="input-notes"
              value={notes}
              onChange={(e) => setNotes(e.target.value)}
              maxLength={2000}
              rows={3}
              placeholder="e.g. Picked up hygiene kit, asked about Thursday hours"
              className="w-full rounded-md border border-input bg-background px-3 py-2 text-sm outline-none focus:ring-2 focus:ring-ring/40"
            />
            <PrivacyNote className="mt-2" />
          </div>

          {err && <p data-testid="text-checkin-error" className="rounded-md border border-destructive/30 bg-destructive/5 p-3 text-sm text-destructive">{err}</p>}
        </div>

        <div className="flex justify-end gap-2 border-t border-border bg-secondary/50 px-6 py-4">
          <button data-testid="button-cancel-checkin" onClick={() => onOpenChange(false)} className="rounded-md px-4 py-2 text-sm font-medium hover:bg-secondary">Cancel</button>
          <button
            data-testid="button-submit-checkin"
            disabled={pending || (mode === 'existing' && !guest)}
            onClick={submit}
            className="inline-flex items-center gap-2 rounded-md bg-primary px-4 py-2 text-sm font-semibold text-primary-foreground transition hover:bg-primary/90 active:scale-[0.98] disabled:opacity-50"
          >
            {pending ? <Loader2 className="h-4 w-4 animate-spin" /> : <Plus className="h-4 w-4" />}
            {mode === 'new' && !preset ? 'Create code & check in' : 'Check in'}
          </button>
        </div>
      </DialogContent>
    </Dialog>
  );
}
