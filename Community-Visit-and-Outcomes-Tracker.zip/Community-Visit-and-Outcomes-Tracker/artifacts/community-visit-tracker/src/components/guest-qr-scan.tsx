import { useRef, useState } from 'react';
import { Loader2, ScanLine } from 'lucide-react';

export function GuestQrScan({ onCode }: { onCode: (code: string) => void }) {
  const input = useRef<HTMLInputElement>(null);
  const [busy, setBusy] = useState(false);
  const [error, setError] = useState<string | null>(null);
  const scan = async (file: File) => {
    setError(null);
    if (file.size > 10 * 1024 * 1024) { setError('Choose a QR image under 10 MB.'); return; }
    setBusy(true);
    const url = URL.createObjectURL(file);
    try {
      // Decode locally. QR images never leave this device.
      const { BrowserQRCodeReader } = await import('@zxing/browser');
      const result = await new BrowserQRCodeReader().decodeFromImageUrl(url);
      const code = result.getText().trim().toUpperCase();
      if (!/^G-[0-9A-F]{8}$/.test(code)) { setError('This is not a Mercy Holisitic Connect guest code.'); return; }
      onCode(code);
    } catch { setError('No guest QR code found. Try a clearer image, or type the printed code.'); }
    finally { URL.revokeObjectURL(url); setBusy(false); if (input.current) input.current.value = ''; }
  };
  return (
    <div>
      <input ref={input} data-testid="input-scan-guest-qr" type="file" accept="image/*" capture="environment" disabled={busy} className="sr-only" onChange={(e) => { const file = e.target.files?.[0]; if (file) void scan(file); }} />
      <button type="button" data-testid="button-scan-guest-qr" disabled={busy} onClick={() => input.current?.click()} className="inline-flex items-center gap-2 rounded-md border border-border bg-card px-3 py-2 text-sm disabled:opacity-50">{busy ? <Loader2 className="h-4 w-4 animate-spin" /> : <ScanLine className="h-4 w-4" />}Scan QR image</button>
      {error && <p role="alert" data-testid="text-qr-scan-error" className="mt-2 max-w-sm text-xs text-destructive">{error}</p>}
    </div>
  );
}
