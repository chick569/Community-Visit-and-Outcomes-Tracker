import { useEffect, useRef, useState } from 'react';
import { Camera, Loader2, Trash2 } from 'lucide-react';
import { deleteGuestPhoto, uploadGuestPhoto } from '@workspace/api-client-react';
import { errorMessage } from '@/lib/format';

const basePath = import.meta.env.BASE_URL.replace(/\/$/, '');
export function GuestPhoto({ clientId, updatedAt, onChanged, onBusy }: {
  clientId: string; updatedAt: string | null; onChanged: (updatedAt: string | null) => void; onBusy: (busy: boolean) => void;
}) {
  const [consent, setConsent] = useState(false);
  const [busy, setBusy] = useState(false);
  const [error, setError] = useState<string | null>(null);
  const [imageFailed, setImageFailed] = useState(false);
  const input = useRef<HTMLInputElement>(null);
  useEffect(() => setImageFailed(false), [updatedAt]);
  const setWorking = (value: boolean) => { setBusy(value); onBusy(value); };
  const upload = async (file: File) => {
    setError(null);
    if (!consent) { setError("Get the guest's permission before saving a photo."); return; }
    if (!['image/jpeg', 'image/png', 'image/webp'].includes(file.type)) { setError('Choose a JPG, PNG, or WebP photo.'); return; }
    if (file.size > 5 * 1024 * 1024) { setError('Choose a photo no larger than 5 MB.'); return; }
    setWorking(true);
    try {
      const result = await uploadGuestPhoto(clientId, file, { headers: { 'Content-Type': file.type } });
      onChanged(result.photoUpdatedAt);
      setConsent(false);
    } catch (err) { setError(errorMessage(err, 'Could not save this photo.')); }
    finally { setWorking(false); if (input.current) input.current.value = ''; }
  };
  const remove = async () => {
    if (!window.confirm('Permanently remove this guest photo? Their other profile details and visits will be kept.')) return;
    setError(null);
    setWorking(true);
    try { const result = await deleteGuestPhoto(clientId); onChanged(result.photoUpdatedAt); }
    catch (err) { setError(errorMessage(err, 'Could not remove this photo.')); }
    finally { setWorking(false); }
  };
  return (
    <section data-testid="guest-photo-section" className="space-y-3">
      <h3 className="text-sm font-semibold">Guest photo <span className="font-normal text-muted-foreground">(optional)</span></h3>
      {updatedAt && !imageFailed ? <img data-testid="image-guest-photo" alt="Guest-provided profile photo" src={`${basePath}/api/clients/${encodeURIComponent(clientId)}/photo?v=${encodeURIComponent(updatedAt)}`} onError={() => setImageFailed(true)} className="h-36 w-36 rounded-md border border-border object-cover" /> : <div data-testid="guest-photo-placeholder" className="flex h-36 w-36 flex-col items-center justify-center gap-2 rounded-md border border-dashed border-border bg-background text-xs text-muted-foreground"><Camera className="h-6 w-6" />{imageFailed ? 'Photo could not load' : 'No photo saved'}</div>}
      <p className="text-xs text-muted-foreground">JPG, PNG or WebP · up to 5 MB. Private to your account; not included on handouts or stakeholder reports. Location metadata is removed.</p>
      <label className="flex items-start gap-2 text-xs"><input data-testid="checkbox-photo-consent" type="checkbox" checked={consent} disabled={busy} onChange={(e) => setConsent(e.target.checked)} /><span>The guest agrees to having this photo saved.</span></label>
      <input ref={input} data-testid="input-guest-photo" type="file" accept="image/jpeg,image/png,image/webp" disabled={busy || !consent} className="sr-only" onChange={(e) => { const file = e.target.files?.[0]; if (file) void upload(file); }} />
      <div className="flex flex-wrap gap-2">
        <button data-testid="button-upload-guest-photo" type="button" disabled={busy || !consent} onClick={() => input.current?.click()} className="inline-flex items-center gap-2 rounded-md border border-border px-3 py-2 text-xs disabled:opacity-50">{busy ? <Loader2 className="h-3 w-3 animate-spin" /> : <Camera className="h-3 w-3" />}{updatedAt ? 'Replace photo' : 'Add photo'}</button>
        {updatedAt && <button data-testid="button-remove-guest-photo" type="button" disabled={busy} onClick={remove} className="inline-flex items-center gap-1 rounded-md border border-border px-3 py-2 text-xs text-destructive disabled:opacity-50"><Trash2 className="h-3 w-3" /> Remove photo</button>}
        {imageFailed && <button type="button" className="text-xs underline" onClick={() => setImageFailed(false)}>Retry photo</button>}
      </div>
      {error && <p role="alert" data-testid="text-photo-error" className="text-xs text-destructive">{error}</p>}
    </section>
  );
}
