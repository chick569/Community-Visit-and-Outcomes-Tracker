import { QRCodeSVG } from 'qrcode.react';
import { Download } from 'lucide-react';
import { useRef } from 'react';

export function GuestQrCode({ code, downloadable = false }: { code: string; downloadable?: boolean }) {
  const wrapper = useRef<HTMLDivElement>(null);
  const download = () => {
    const svg = wrapper.current?.querySelector('svg');
    if (!svg) return;
    const url = URL.createObjectURL(new Blob([new XMLSerializer().serializeToString(svg)], { type: 'image/svg+xml' }));
    const link = document.createElement('a');
    link.href = url;
    link.download = `Mercy-guest-${code}-QR.svg`;
    link.click();
    setTimeout(() => URL.revokeObjectURL(url), 1000);
  };
  return (
    <div data-testid="guest-qr" className="flex flex-col items-center gap-2">
      <div ref={wrapper} className="rounded-md bg-white p-2"><QRCodeSVG value={code} size={144} level="M" marginSize={4} title={`Guest code ${code}`} /></div>
      <span className="font-code text-sm">{code}</span>
      {downloadable && <button type="button" data-testid="button-download-guest-qr" onClick={download} className="inline-flex items-center gap-2 rounded-md border border-border px-3 py-2 text-xs"><Download className="h-3 w-3" /> Download QR</button>}
    </div>
  );
}
