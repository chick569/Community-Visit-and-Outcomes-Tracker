import type { ReactNode } from 'react';
import { AlertTriangle, RotateCw, ShieldAlert } from 'lucide-react';
import { SERVICE_TONE, serviceLabel, errorMessage } from '@/lib/format';
import { cn } from '@/lib/utils';

export function StatusPill({ status }: { status: string }) {
  const onSite = status === 'on-site';
  return (
    <span
      data-testid={`status-${status}`}
      className={cn(
        'inline-flex items-center gap-1.5 rounded-full px-2 py-0.5 text-[11px] font-semibold uppercase tracking-wider',
        onSite ? 'bg-accent text-accent-foreground' : 'bg-secondary text-muted-foreground',
      )}
    >
      <span className="relative flex h-1.5 w-1.5">
        {onSite && <span className="beat absolute inset-0 rounded-full bg-[hsl(14_80%_56%)]" />}
        <span className={cn('relative h-1.5 w-1.5 rounded-full', onSite ? 'bg-[hsl(14_80%_56%)]' : 'bg-muted-foreground/50')} />
      </span>
      {onSite ? 'On site' : 'Completed'}
    </span>
  );
}

export function ServiceTag({ service }: { service: string }) {
  return (
    <span className="inline-flex items-center gap-1.5 text-sm">
      <span className="h-2 w-2 rounded-[2px]" style={{ background: SERVICE_TONE[service] ?? SERVICE_TONE.other }} />
      {serviceLabel(service)}
    </span>
  );
}

export function GuestCode({ code, className }: { code: string; className?: string }) {
  return (
    <span className={cn('font-code rounded border border-border bg-card px-1.5 py-0.5 text-[13px] font-medium tracking-wide', className)}>
      {code}
    </span>
  );
}

export function PageHead({ kicker, title, children }: { kicker: string; title: string; children?: ReactNode }) {
  return (
    <div className="rise mb-8 flex flex-col gap-4 border-b border-foreground/15 pb-6 md:flex-row md:items-end md:justify-between">
      <div>
        <p className="font-code text-[11px] uppercase tracking-[0.2em] text-primary">{kicker}</p>
        <h1 className="font-display mt-2 text-4xl font-semibold leading-none tracking-tight md:text-5xl">{title}</h1>
      </div>
      {children && <div className="no-print flex flex-wrap items-center gap-2">{children}</div>}
    </div>
  );
}

export function ErrorPanel({ error, onRetry }: { error: unknown; onRetry: () => void }) {
  return (
    <div data-testid="status-error" className="flex flex-col items-start gap-3 rounded-md border border-destructive/30 bg-destructive/5 p-5">
      <div className="flex items-center gap-2 font-semibold text-destructive">
        <AlertTriangle className="h-4 w-4" /> Couldn't load this
      </div>
      <p className="text-sm text-muted-foreground">{errorMessage(error)}</p>
      <button data-testid="button-retry" onClick={onRetry} className="inline-flex items-center gap-2 rounded-md border border-border bg-card px-3 py-1.5 text-sm font-medium hover:bg-secondary">
        <RotateCw className="h-3.5 w-3.5" /> Try again
      </button>
    </div>
  );
}

export function EmptyState({ title, body, action }: { title: string; body: string; action?: ReactNode }) {
  return (
    <div className="ledger-rule flex flex-col items-center rounded-md border border-dashed border-foreground/20 bg-card/60 px-6 py-14 text-center">
      <div className="font-code mb-4 text-xs tracking-[0.3em] text-muted-foreground">— NO ENTRIES —</div>
      <h3 className="font-display text-2xl font-semibold">{title}</h3>
      <p className="mt-2 max-w-sm text-sm text-muted-foreground">{body}</p>
      {action && <div className="mt-5">{action}</div>}
    </div>
  );
}

export function PrivacyNote({ className }: { className?: string }) {
  return (
    <p className={cn('flex gap-2 rounded-md bg-[hsl(42_78%_52%/0.14)] p-2.5 text-xs leading-relaxed text-foreground/80', className)}>
      <ShieldAlert className="mt-0.5 h-3.5 w-3.5 shrink-0 text-[hsl(30_70%_38%)]" />
      Keep notes operational. Do not record names, contact details, medical or diagnostic information, or anything that could identify a guest.
    </p>
  );
}

export function Bar({ className }: { className?: string }) {
  return <div className={cn('animate-pulse rounded bg-foreground/[0.07]', className)} />;
}
