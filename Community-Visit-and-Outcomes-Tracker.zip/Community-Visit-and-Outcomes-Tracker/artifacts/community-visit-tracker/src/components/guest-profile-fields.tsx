import { useEffect, useState } from 'react';
import type { UseFormReturn } from 'react-hook-form';
import type { GuestDemographics } from '@workspace/api-client-react';
import { FormField, FormItem, FormMessage } from '@/components/ui/form';
import { cn } from '@/lib/utils';

const PRIVATE = 'Prefer not to say';
const chipClass = (active: boolean) => cn(
  'rounded-full border px-3 py-2 text-sm transition focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-ring',
  active ? 'border-primary bg-primary text-primary-foreground' : 'border-border bg-background hover:border-primary/60',
);

export function profileDefaults(profile?: GuestDemographics): GuestDemographics {
  return {
    races: profile?.races ?? [], gender: profile?.gender ?? null,
    sex: profile?.sex ?? null, nationality: profile?.nationality ?? null, ethnicity: profile?.ethnicity ?? null,
    languages: profile?.languages ?? [], ageRange: profile?.ageRange ?? null,
  };
}

export function profileRows(profile?: GuestDemographics) {
  return [
    ['Race', profile?.races?.join(', ')],
    ['Gender', profile?.gender], ['Sex', profile?.sex],
    ['Ethnicity', profile?.ethnicity], ['Previous nationality response', profile?.nationality], ['Language', profile?.languages?.join(', ')],
    ['Age range', profile?.ageRange],
  ].filter((row): row is [string, string] => !!row[1]);
}

function SingleChoice({ name, label, options, value, onChange, customLabel }: {
  name: string; label: string; options: readonly string[]; value: string | null | undefined;
  onChange: (value: string | null) => void; customLabel?: string;
}) {
  const [custom, setCustom] = useState(value != null && !options.includes(value));
  useEffect(() => setCustom(value != null && !options.includes(value)), [value, options]);
  return (
    <fieldset className="space-y-2" data-testid={`field-${name}`}>
      <legend className="mb-2 text-sm font-semibold">{label}</legend>
      <div className="flex flex-wrap gap-2">
        <button type="button" aria-pressed={value == null} className={chipClass(value == null)} onClick={() => { setCustom(false); onChange(null); }} data-testid={`button-${name}-clear`}>Not provided</button>
        {options.map((option, i) => <button type="button" key={option} aria-pressed={value === option} className={chipClass(value === option)} onClick={() => { setCustom(false); onChange(option); }} data-testid={`button-${name}-${i}`}>{option}</button>)}
        {customLabel && <button type="button" aria-pressed={custom} className={chipClass(custom)} onClick={() => { if (!custom) { setCustom(true); onChange(''); } }} data-testid={`button-${name}-custom`}>{customLabel}</button>}
      </div>
      {custom && <label className="block text-xs text-muted-foreground">
        Guest's own words (optional)
        <input value={value ?? ''} maxLength={100} onChange={(e) => onChange(e.target.value)} aria-label={`${label}, guest's own words`} data-testid={`input-${name}-custom`} className="mt-1 block w-full rounded-md border border-input bg-background px-3 py-2 text-sm text-foreground" />
      </label>}
    </fieldset>
  );
}

function MultipleChoice({ name, label, options, value = [], onChange }: {
  name: string; label: string; options: readonly string[]; value?: string[];
  onChange: (value: string[]) => void;
}) {
  const [extra, setExtra] = useState('');
  const allOptions = [...options, ...value.filter((v) => !options.includes(v))];
  const toggle = (option: string) => {
    if (value.includes(option)) onChange(value.filter((v) => v !== option));
    else if (option === PRIVATE) onChange([PRIVATE]);
    else if (value.filter((v) => v !== PRIVATE).length < 10) onChange([...value.filter((v) => v !== PRIVATE), option]);
  };
  const add = () => {
    const text = extra.trim();
    if (!text || value.some((v) => v.toLowerCase() === text.toLowerCase()) || value.length >= 10) return;
    toggle(text);
    setExtra('');
  };
  return (
    <fieldset className="space-y-2" data-testid={`field-${name}`}>
      <legend className="mb-1 text-sm font-semibold">{label} <span className="font-normal text-muted-foreground">(select any shared)</span></legend>
      <div className="flex flex-wrap gap-2">
        <button type="button" aria-pressed={!value.length} className={chipClass(!value.length)} onClick={() => onChange([])} data-testid={`button-${name}-clear`}>Not provided</button>
        {allOptions.map((option, i) => <button type="button" key={option} aria-pressed={value.includes(option)} className={chipClass(value.includes(option))} onClick={() => toggle(option)} data-testid={`button-${name}-${i}`}>{option}</button>)}
      </div>
      <div className="flex gap-2">
        <input value={extra} maxLength={100} onChange={(e) => setExtra(e.target.value)} placeholder="Another response in the guest's own words" aria-label={`Another ${label.toLowerCase()} response`} data-testid={`input-${name}-other`} className="min-w-0 flex-1 rounded-md border border-input bg-background px-3 py-2 text-sm" onKeyDown={(e) => { if (e.key === 'Enter') { e.preventDefault(); add(); } }} />
        <button type="button" data-testid={`button-${name}-add`} disabled={!extra.trim() || value.length >= 10} onClick={add} className="rounded-md border border-border px-3 py-2 text-sm disabled:opacity-50">Add</button>
      </div>
    </fieldset>
  );
}

const SINGLE_FIELDS = [
  { name: 'gender', label: 'Gender', options: ['Woman', 'Man', 'Nonbinary', PRIVATE], customLabel: 'Self-describe' },
  { name: 'sex', label: 'Sex', options: ['Female', 'Male', 'Intersex', PRIVATE], customLabel: 'Another description' },
  { name: 'ethnicity', label: 'Ethnicity', options: ['Hispanic or Latino', 'Not Hispanic or Latino', PRIVATE], customLabel: 'Self-describe ethnicity' },
  { name: 'ageRange', label: 'Age range', options: ['Under 18', '18–24', '25–34', '35–44', '45–54', '55–64', '65+', PRIVATE] },
] as const;
const RACES = ['American Indian or Alaska Native', 'Asian', 'Black or African American', 'Middle Eastern or North African', 'Native Hawaiian or Pacific Islander', 'White', PRIVATE];
const LANGUAGES = ['English', 'Spanish', 'American Sign Language', 'Arabic', 'Chinese', 'French', 'Vietnamese', PRIVATE];

export function GuestProfileFields({ form }: { form: UseFormReturn<GuestDemographics> }) {
  return (
    <div className="space-y-5">
      <p className="rounded-md border border-primary/20 bg-primary/5 p-3 text-xs leading-relaxed">All fields are optional and self-reported. Ask the guest; do not guess from appearance, name, accent, or photo. Gender and sex are separate responses. Ethnicity is not nationality or immigration status. Choose Not provided to leave a field blank. These details stay out of stakeholder reports.</p>
      <FormField control={form.control} name="races" render={({ field }) => <FormItem><MultipleChoice name="race" label="Race" options={RACES} value={field.value} onChange={field.onChange} /><FormMessage /></FormItem>} />
      {SINGLE_FIELDS.map((config) => <FormField key={config.name} control={form.control} name={config.name} render={({ field }) => (
        <FormItem><SingleChoice name={config.name} label={config.label} options={config.options} customLabel={'customLabel' in config ? config.customLabel : undefined} value={field.value} onChange={field.onChange} /><FormMessage /></FormItem>
      )} />)}
      <FormField control={form.control} name="languages" render={({ field }) => <FormItem><MultipleChoice name="language" label="Language" options={LANGUAGES} value={field.value} onChange={field.onChange} /><FormMessage /></FormItem>} />
    </div>
  );
}
