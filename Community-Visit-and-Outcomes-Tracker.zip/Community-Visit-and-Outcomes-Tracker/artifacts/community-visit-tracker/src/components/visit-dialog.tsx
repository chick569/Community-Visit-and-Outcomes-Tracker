import { useEffect, useState } from 'react';
import { Loader2, LogOut } from 'lucide-react';
import { useUpdateVisit, type Visit } from '@workspace/api-client-react';
import { Dialog, DialogContent, DialogDescription, DialogHeader, DialogTitle } from '@/components/ui/dialog';
import { useToast } from '@/hooks/use-toast';
import { GuestCode, PrivacyNote, ServiceTag, StatusPill } from '@/components/bits';
import { OUTCOMES, duration, errorMessage, fmtDate, fmtTime, useInvalidateAll, type OutcomeValue } from '@/lib/format';
import { SupportLocationField } from '@/components/support-location-field';

export function VisitDialog({ visit, onClose }: { visit: Visit | null; onClose: () => void }) {
  const [notes, setNotes] = useState('');
  const [location, setLocation] = useState('');
  const [outcome, setOutcome] = useState<OutcomeValue | ''>('');
  const [err, setErr] = useState<string | null>(null);
  const update = useUpdateVisit();
  const invalidate = useInvalidateAll();
  const { toast } = useToast();

  useEffect(() => {
    if (visit) {
      setNotes(visit.notes ?? '');
      setLocation(visit.location ?? '');
      setOutcome((visit.outcome as OutcomeValue | null) ?? '');
      setErr(null);
    }
  }, [visit]);

  const run = (data: Parameters<typeof update.mutate>[0]['data'], msg: string) => {
    if (!visit) return;
    setErr(null);
    update.mutate(
      { visitId: visit.id, data },
      {
        onSuccess: (v) => {
          invalidate();
          toast({ title: msg, description: `Guest ${v.clientCode}` });
          onClose();
        },
        onError: (e) => setErr(errorMessage(e, 'Update failed.')),
      },
    );
  };

  const save = () => run({ notes: notes.trim() ? notes.trim() : null, outcome: outcome || null, location: location.trim() || null }, 'Visit updated');
  const depart = () =>
    run({ departedAt: new Date().toISOString(), notes: notes.trim() ? notes.trim() : null, outcome: outcome || null, location: location.trim() || null }, 'Departure recorded');

  return (
    <Dialog open={!!visit} onOpenChange={(o) => !o && onClose()}>
      <DialogContent className="max-h-[92dvh] max-w-lg overflow-y-auto border-foreground/15 bg-card p-0">
        {visit && (
          <>
            <div className="border-b border-border px-6 py-5">
              <DialogHeader>
                <div className="flex items-center gap-3">
                  <GuestCode code={visit.clientCode} className="text-base" />
                  <StatusPill status={visit.status} />
                </div>
                <DialogTitle className="font-display pt-2 text-2xl font-semibold">Visit on {fmtDate(visit.arrivedAt)}</DialogTitle>
                <DialogDescription>Edit the support location, notes and outcome, or record the departure.</DialogDescription>
              </DialogHeader>
              <dl className="mt-4 grid grid-cols-3 gap-3 text-sm">
                <div><dt className="text-xs text-muted-foreground">Arrived</dt><dd className="font-code">{fmtTime(visit.arrivedAt)}</dd></div>
                <div><dt className="text-xs text-muted-foreground">Departed</dt><dd className="font-code">{fmtTime(visit.departedAt)}</dd></div>
                <div><dt className="text-xs text-muted-foreground">Length</dt><dd className="font-code">{duration(visit.arrivedAt, visit.departedAt)}</dd></div>
              </dl>
              <div className="mt-3"><ServiceTag service={visit.service} /></div>
            </div>
            <div className="space-y-4 px-6 py-5">
              <SupportLocationField value={location} onChange={setLocation} enabled={!!visit} editing />
              <div>
                <p className="mb-2 text-xs font-semibold uppercase tracking-wider text-muted-foreground">Outcome</p>
                <select data-testid="select-edit-outcome" value={outcome} onChange={(e) => setOutcome(e.target.value as OutcomeValue | '')} className="w-full rounded-md border border-input bg-background px-3 py-2 text-sm">
                  <option value="">None recorded</option>
                  {OUTCOMES.map((o) => <option key={o.value} value={o.value}>{o.label}</option>)}
                </select>
              </div>
              <div>
                <p className="mb-2 flex justify-between text-xs font-semibold uppercase tracking-wider text-muted-foreground">
                  Notes <span className="font-code normal-case tracking-normal">{notes.length}/2000</span>
                </p>
                <textarea data-testid="input-edit-notes" value={notes} onChange={(e) => setNotes(e.target.value)} maxLength={2000} rows={4} placeholder="Leave blank to clear notes" className="w-full rounded-md border border-input bg-background px-3 py-2 text-sm outline-none focus:ring-2 focus:ring-ring/40" />
                <PrivacyNote className="mt-2" />
              </div>
              {err && <p data-testid="text-update-error" className="rounded-md border border-destructive/30 bg-destructive/5 p-3 text-sm text-destructive">{err}</p>}
            </div>
            <div className="flex flex-wrap justify-end gap-2 border-t border-border bg-secondary/50 px-6 py-4">
              <button data-testid="button-save-visit" disabled={update.isPending} onClick={save} className="rounded-md border border-border bg-card px-4 py-2 text-sm font-medium hover:bg-secondary disabled:opacity-50">
                Save changes
              </button>
              {visit.status === 'on-site' && (
                <button data-testid="button-record-departure" disabled={update.isPending} onClick={depart} className="inline-flex items-center gap-2 rounded-md bg-[hsl(14_80%_52%)] px-4 py-2 text-sm font-semibold text-white transition hover:bg-[hsl(14_80%_46%)] active:scale-[0.98] disabled:opacity-50">
                  {update.isPending ? <Loader2 className="h-4 w-4 animate-spin" /> : <LogOut className="h-4 w-4" />}
                  Check out now
                </button>
              )}
            </div>
          </>
        )}
      </DialogContent>
    </Dialog>
  );
}
