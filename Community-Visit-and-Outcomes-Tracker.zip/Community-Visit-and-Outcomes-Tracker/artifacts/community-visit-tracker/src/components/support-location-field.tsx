import { useId } from 'react';
import { getListSupportLocationsQueryKey, useListSupportLocations } from '@workspace/api-client-react';

export function SupportLocationField({ value, onChange, enabled = true, editing = false }: {
  value: string; onChange: (value: string) => void; enabled?: boolean; editing?: boolean;
}) {
  const id = useId();
  const locations = useListSupportLocations({ query: { queryKey: getListSupportLocationsQueryKey(), enabled } });
  return (
    <div>
      <label htmlFor={id} className="mb-2 block text-xs font-semibold uppercase tracking-wider text-muted-foreground">Support location (optional)</label>
      <input id={id} list={`${id}-locations`} data-testid={editing ? 'input-edit-support-location' : 'input-support-location'} value={value} onChange={(e) => onChange(e.target.value)} maxLength={200} placeholder="e.g. Mercy center or Downtown outreach" className="w-full rounded-md border border-input bg-background px-3 py-2 text-sm outline-none focus:ring-2 focus:ring-ring/40" />
      <datalist id={`${id}-locations`}>{locations.data?.map((location) => <option key={location} value={location} />)}</datalist>
      <p className="mt-2 text-xs text-muted-foreground">Enter a service site or outreach area, not a guest's home or sleeping location. Included in guest summaries and location totals in reports. No GPS tracking.</p>
      {locations.isError && <p className="mt-1 text-xs text-muted-foreground">Saved-site suggestions could not load. You can still enter a location.</p>}
    </div>
  );
}
