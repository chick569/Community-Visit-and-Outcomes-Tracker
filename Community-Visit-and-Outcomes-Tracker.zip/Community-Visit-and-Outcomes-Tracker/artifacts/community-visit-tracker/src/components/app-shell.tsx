import { useState, type ReactNode } from 'react';
import { Link, useLocation } from 'wouter';
import { useClerk, useUser } from '@clerk/react';
import { LogOut, Plus } from 'lucide-react';
import { CheckInDialog } from '@/components/check-in-dialog';
import { cn } from '@/lib/utils';

const basePath = import.meta.env.BASE_URL.replace(/\/$/, '');

const NAV = [
  { href: '/dashboard', label: 'Today', n: '01' },
  { href: '/visits', label: 'Visits', n: '02' },
  { href: '/guests', label: 'Guests', n: '03' },
  { href: '/reports', label: 'Reports', n: '04' },
  { href: '/staff-time', label: 'Staff time', n: '05' },
  { href: '/privacy', label: 'Privacy', n: '06' },
];

export function Logo({ light }: { light?: boolean }) {
  return (
    <span className="flex items-center gap-2.5" aria-label="Mercy Holisitic Connect">
      <img src={`${basePath}/logo.svg`} alt="" className="h-7 w-7" />
      <span className={cn('font-display text-sm font-semibold leading-tight tracking-tight sm:text-base', light && 'text-[hsl(40_30%_94%)]')}>
        Mercy Holisitic{' '}<span className="block">Connect</span>
      </span>
    </span>
  );
}

export function AppShell({ children }: { children: ReactNode }) {
  const [location] = useLocation();
  const { signOut } = useClerk();
  const { user } = useUser();
  const [open, setOpen] = useState(false);
  const email = user?.primaryEmailAddress?.emailAddress ?? '';

  return (
    <div className="min-h-[100dvh]">
      <header className="no-print sticky top-0 z-40 bg-[hsl(198_42%_14%)] text-[hsl(40_30%_92%)]">
        <div className="mx-auto flex h-14 max-w-7xl items-center gap-6 px-4 md:px-8">
          <Link href="/dashboard" data-testid="link-home"><Logo light /></Link>
          <nav className="hidden flex-1 items-center gap-1 lg:flex">
            {NAV.map((n) => {
              const active = location.startsWith(n.href);
              return (
                <Link key={n.href} href={n.href} data-testid={`link-nav-${n.label.toLowerCase()}`} className={cn('group relative flex items-baseline gap-1.5 px-3 py-4 text-sm transition', active ? 'text-white' : 'text-[hsl(40_20%_72%)] hover:text-white')}>
                  <span className="font-code text-[10px] opacity-50">{n.n}</span>
                  {n.label}
                  <span className={cn('absolute inset-x-3 bottom-0 h-[3px] origin-left bg-[hsl(14_80%_56%)] transition-transform duration-300', active ? 'scale-x-100' : 'scale-x-0 group-hover:scale-x-50')} />
                </Link>
              );
            })}
          </nav>
          <div className="ml-auto flex items-center gap-2">
            <button data-testid="button-open-checkin" onClick={() => setOpen(true)} className="inline-flex items-center gap-1.5 rounded-md bg-[hsl(14_80%_56%)] px-3 py-1.5 text-sm font-semibold text-white transition hover:bg-[hsl(14_80%_50%)] active:scale-95">
              <Plus className="h-4 w-4" /> Check in
            </button>
            <span className="hidden max-w-[180px] truncate text-xs text-[hsl(40_20%_68%)] xl:inline" data-testid="text-user-email">{email}</span>
            <button data-testid="button-sign-out" title="Sign out" onClick={() => signOut({ redirectUrl: basePath || '/' })} className="rounded-md p-2 text-[hsl(40_20%_72%)] hover:bg-white/10 hover:text-white">
              <LogOut className="h-4 w-4" />
            </button>
          </div>
        </div>
        <nav className="flex border-t border-white/10 lg:hidden">
          {NAV.map((n) => (
            <Link key={n.href} href={n.href} data-testid={`link-mnav-${n.label.toLowerCase()}`} className={cn('flex-1 py-2.5 text-center text-sm', location.startsWith(n.href) ? 'bg-white/10 text-white' : 'text-[hsl(40_20%_72%)]')}>
              {n.label}
            </Link>
          ))}
        </nav>
      </header>
      <main className="print-full mx-auto max-w-7xl px-4 py-8 md:px-8 md:py-10">{children}</main>
      <CheckInDialog open={open} onOpenChange={setOpen} />
    </div>
  );
}
