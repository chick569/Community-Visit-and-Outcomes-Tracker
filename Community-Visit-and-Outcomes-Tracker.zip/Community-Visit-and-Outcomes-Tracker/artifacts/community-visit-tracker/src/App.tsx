import { useEffect, useRef, type ComponentType, type ReactNode } from 'react';
import { QueryClient, QueryClientProvider, useQueryClient } from '@tanstack/react-query';
import { ClerkProvider, SignIn, SignUp, Show, useClerk } from '@clerk/react';
import { publishableKeyFromHost } from '@clerk/react/internal';
import { shadcn } from '@clerk/themes';
import { Redirect, Route, Switch, useLocation, Router as WouterRouter } from 'wouter';
import { ErrorBoundary } from '@/components/error-boundary';
import { Toaster } from '@/components/ui/toaster';
import { TooltipProvider } from '@/components/ui/tooltip';
import { AppShell } from '@/components/app-shell';
import NotFound from '@/pages/not-found';
import Landing from '@/pages/landing';
import Dashboard from '@/pages/dashboard';
import Visits from '@/pages/visits';
import Guests from '@/pages/guests';
import Reports from '@/pages/reports';
import StaffTime from '@/pages/staff-time';
import Privacy from '@/pages/privacy';

const queryClient = new QueryClient({
  defaultOptions: { queries: { retry: 1, refetchOnWindowFocus: true } },
});

const clerkPubKey = publishableKeyFromHost(
  window.location.hostname,
  import.meta.env.VITE_CLERK_PUBLISHABLE_KEY,
);

const clerkProxyUrl = import.meta.env.VITE_CLERK_PROXY_URL;

const basePath = import.meta.env.BASE_URL.replace(/\/$/, '');

function stripBase(path: string): string {
  return basePath && path.startsWith(basePath)
    ? path.slice(basePath.length) || '/'
    : path;
}

if (!clerkPubKey) {
  throw new Error('Missing VITE_CLERK_PUBLISHABLE_KEY in .env file');
}

const clerkAppearance = {
  theme: shadcn,
  cssLayerName: 'clerk',
  options: {
    logoPlacement: 'inside' as const,
    logoLinkUrl: basePath || '/',
    logoImageUrl: `${window.location.origin}${basePath}/logo.svg`,
  },
  variables: {
    colorPrimary: 'hsl(186 58% 26%)',
    colorForeground: 'hsl(198 42% 14%)',
    colorMutedForeground: 'hsl(198 14% 38%)',
    colorDanger: 'hsl(2 66% 46%)',
    colorBackground: 'hsl(42 40% 98%)',
    colorInput: 'hsl(40 30% 95%)',
    colorInputForeground: 'hsl(198 42% 14%)',
    colorNeutral: 'hsl(198 30% 30%)',
    fontFamily: "'Bricolage Grotesque', sans-serif",
    borderRadius: '0.375rem',
  },
  elements: {
    rootBox: 'w-full flex justify-center',
    cardBox: 'bg-[hsl(42_40%_98%)] rounded-md w-[420px] max-w-full overflow-hidden border border-[hsl(198_42%_14%/0.15)] shadow-[0_24px_60px_-24px_hsl(198_42%_14%/0.45)]',
    card: '!shadow-none !border-0 !bg-transparent !rounded-none',
    footer: '!shadow-none !border-0 !bg-transparent !rounded-none',
    headerTitle: "text-[hsl(198_42%_14%)] text-2xl font-semibold [font-family:'Fraunces',serif]",
    headerSubtitle: 'text-[hsl(198_14%_38%)]',
    socialButtonsBlockButtonText: 'text-[hsl(198_42%_14%)] font-medium',
    formFieldLabel: 'text-[hsl(198_42%_14%)] font-medium',
    footerActionLink: 'text-[hsl(14_75%_44%)] font-semibold hover:text-[hsl(14_75%_36%)]',
    footerActionText: 'text-[hsl(198_14%_38%)]',
    dividerText: 'text-[hsl(198_14%_42%)]',
    identityPreviewEditButton: 'text-[hsl(186_58%_26%)]',
    formFieldSuccessText: 'text-[hsl(150_40%_30%)]',
    alertText: 'text-[hsl(2_66%_36%)]',
    logoBox: 'h-10 justify-center',
    logoImage: 'h-10 w-10',
    socialButtonsBlockButton: 'border border-[hsl(38_20%_80%)] bg-[hsl(42_40%_98%)] hover:bg-[hsl(38_28%_91%)]',
    formButtonPrimary: 'bg-[hsl(186_58%_26%)] text-[hsl(40_40%_97%)] font-semibold shadow-none',
    formFieldInput: 'bg-[hsl(40_30%_95%)] border-[hsl(38_18%_78%)] text-[hsl(198_42%_14%)]',
    footerAction: 'bg-[hsl(38_28%_92%)] py-3 justify-center',
    dividerLine: 'bg-[hsl(38_20%_82%)]',
    alert: 'bg-[hsl(2_66%_46%/0.06)] border border-[hsl(2_66%_46%/0.25)]',
    otpCodeFieldInput: 'border-[hsl(38_18%_74%)] text-[hsl(198_42%_14%)]',
    formFieldRow: 'mb-1',
    main: 'gap-5',
  },
};

function AuthFrame({ children, line }: { children: ReactNode; line: string }) {
  return (
    <div className="grid min-h-[100dvh] md:grid-cols-[1fr_1.1fr]">
      <div className="relative hidden flex-col justify-between overflow-hidden bg-[hsl(198_42%_14%)] p-10 text-[hsl(40_30%_94%)] md:flex">
        <span className="font-display text-xl font-semibold">Tally<span className="text-[hsl(14_80%_56%)]">/</span>Visits</span>
        <div>
          <p className="font-display text-5xl font-semibold leading-[1.02]">{line}</p>
          <p className="mt-5 max-w-sm text-sm text-[hsl(40_20%_74%)]">Anonymous guest codes. Honest daily counts. Reports with no one's story in them.</p>
        </div>
        <div className="font-code flex gap-6 text-xs text-[hsl(40_20%_64%)]">
          <span>K7Q-4M2</span><span>R2D-9XA</span><span>B5T-1LP</span>
        </div>
        <div className="absolute -right-24 top-1/3 h-72 w-72 rounded-full border-[28px] border-[hsl(14_80%_56%/0.18)]" />
      </div>
      <div className="flex items-center justify-center bg-background px-4 py-10">{children}</div>
    </div>
  );
}

function SignInPage() {
  return (
    <AuthFrame line="The doors open soon. Your log is ready.">
      <SignIn routing="path" path={`${basePath}/sign-in`} signUpUrl={`${basePath}/sign-up`} />
    </AuthFrame>
  );
}

function SignUpPage() {
  return (
    <AuthFrame line="Start counting what your team already does.">
      <SignUp routing="path" path={`${basePath}/sign-up`} signInUrl={`${basePath}/sign-in`} />
    </AuthFrame>
  );
}

function ClerkQueryClientCacheInvalidator() {
  const { addListener } = useClerk();
  const qc = useQueryClient();
  const prevUserIdRef = useRef<string | null | undefined>(undefined);

  useEffect(() => {
    const unsubscribe = addListener(({ user }) => {
      const userId = user?.id ?? null;
      if (prevUserIdRef.current !== undefined && prevUserIdRef.current !== userId) {
        qc.clear();
      }
      prevUserIdRef.current = userId;
    });
    return unsubscribe;
  }, [addListener, qc]);

  return null;
}

function HomeRedirect() {
  return (
    <>
      <Show when="signed-in">
        <Redirect to="/dashboard" />
      </Show>
      <Show when="signed-out">
        <Landing />
      </Show>
    </>
  );
}

function protect(Page: ComponentType) {
  return function Protected() {
    return (
      <>
        <Show when="signed-in">
          <AppShell>
            <RoutedErrorBoundary>
              <Page />
            </RoutedErrorBoundary>
          </AppShell>
        </Show>
        <Show when="signed-out">
          <Redirect to="/" />
        </Show>
      </>
    );
  };
}

const DashboardRoute = protect(Dashboard);
const VisitsRoute = protect(Visits);
const GuestsRoute = protect(Guests);
const ReportsRoute = protect(Reports);
const StaffTimeRoute = protect(StaffTime);
const PrivacyRoute = protect(Privacy);

function RoutedErrorBoundary({ children }: { children: ReactNode }) {
  const [location] = useLocation();
  return <ErrorBoundary resetKey={location}>{children}</ErrorBoundary>;
}

function ClerkProviderWithRoutes() {
  const [, setLocation] = useLocation();

  return (
    <ClerkProvider
      publishableKey={clerkPubKey}
      proxyUrl={clerkProxyUrl}
      appearance={clerkAppearance}
      signInUrl={`${basePath}/sign-in`}
      signUpUrl={`${basePath}/sign-up`}
      localization={{
        signIn: { start: { title: 'Open today\'s log', subtitle: 'Sign in to record and review visits' } },
        signUp: { start: { title: 'Create your visit log', subtitle: 'Private to your account. No guest names, ever.' } },
      }}
      routerPush={(to) => setLocation(stripBase(to))}
      routerReplace={(to) => setLocation(stripBase(to), { replace: true })}
    >
      <QueryClientProvider client={queryClient}>
        <ClerkQueryClientCacheInvalidator />
        <TooltipProvider>
          <Switch>
            <Route path="/" component={HomeRedirect} />
            <Route path="/sign-in/*?" component={SignInPage} />
            <Route path="/sign-up/*?" component={SignUpPage} />
            <Route path="/dashboard" component={DashboardRoute} />
            <Route path="/visits" component={VisitsRoute} />
            <Route path="/guests" component={GuestsRoute} />
            <Route path="/reports" component={ReportsRoute} />
            <Route path="/staff-time" component={StaffTimeRoute} />
            <Route path="/privacy" component={PrivacyRoute} />
            <Route component={NotFound} />
          </Switch>
          <Toaster />
        </TooltipProvider>
      </QueryClientProvider>
    </ClerkProvider>
  );
}

function App() {
  return (
    <WouterRouter base={basePath}>
      <ClerkProviderWithRoutes />
    </WouterRouter>
  );
}

export default App;
