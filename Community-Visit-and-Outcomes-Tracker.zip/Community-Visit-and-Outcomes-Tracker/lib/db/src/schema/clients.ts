import { pgTable, text, timestamp, uuid, uniqueIndex, jsonb } from "drizzle-orm/pg-core";
import { createInsertSchema } from "drizzle-zod";
import { z } from "zod/v4";

export const clientsTable = pgTable("clients", {
  id: uuid("id").defaultRandom().primaryKey(),
  ownerId: text("owner_id").notNull(),
  code: text("code").notNull(),
  description: text("description"),
  demographics: jsonb("demographics").$type<Record<string, unknown>>().notNull().default({}),
  sensitiveUpdatedAt: timestamp("sensitive_updated_at", { withTimezone: true }),
  photoObjectPath: text("photo_object_path"),
  photoUpdatedAt: timestamp("photo_updated_at", { withTimezone: true }),
  createdAt: timestamp("created_at", { withTimezone: true }).defaultNow().notNull(),
}, (table) => [uniqueIndex("clients_owner_code_idx").on(table.ownerId, table.code)]);

export const insertClientSchema = createInsertSchema(clientsTable).omit({ id: true, createdAt: true });
export type InsertClient = z.infer<typeof insertClientSchema>;
export type Client = typeof clientsTable.$inferSelect;
