import { pgTable, text, timestamp, uuid, index, uniqueIndex, check } from "drizzle-orm/pg-core";
import { sql } from "drizzle-orm";
import { createInsertSchema } from "drizzle-zod";
import { z } from "zod/v4";
import { clientsTable } from "./clients";

export const visitsTable = pgTable("visits", {
  id: uuid("id").defaultRandom().primaryKey(),
  ownerId: text("owner_id").notNull(),
  clientId: uuid("client_id").notNull().references(() => clientsTable.id),
  arrivedAt: timestamp("arrived_at", { withTimezone: true }).defaultNow().notNull(),
  departedAt: timestamp("departed_at", { withTimezone: true }),
  service: text("service", { enum: ["shelter", "meals", "hygiene", "case-management", "outreach", "other"] }).notNull(),
  outcome: text("outcome", { enum: ["connected-to-services", "return-planned", "other"] }),
  notes: text("notes"),
  location: text("location"),
}, (table) => [
  index("visits_owner_arrived_idx").on(table.ownerId, table.arrivedAt),
  uniqueIndex("visits_one_active_per_guest_idx").on(table.ownerId, table.clientId).where(sql`${table.departedAt} IS NULL`),
  check("visits_departure_after_arrival", sql`${table.departedAt} IS NULL OR ${table.departedAt} >= ${table.arrivedAt}`),
]);

export const insertVisitSchema = createInsertSchema(visitsTable).omit({ id: true, arrivedAt: true });
export type InsertVisit = z.infer<typeof insertVisitSchema>;
export type Visit = typeof visitsTable.$inferSelect;
