import { pgTable, text, integer, timestamp, check } from "drizzle-orm/pg-core";
import { sql } from "drizzle-orm";
import { createInsertSchema } from "drizzle-zod";
import { z } from "zod/v4";

export const privacySettingsTable = pgTable("privacy_settings", {
  ownerId: text("owner_id").primaryKey(),
  // NULL is deliberately the default: no automatic removal without consent.
  retentionDays: integer("retention_days"),
  updatedAt: timestamp("updated_at", { withTimezone: true }).defaultNow().notNull(),
}, (t) => [check("retention_days_range", sql`${t.retentionDays} is null or ${t.retentionDays} between 1 and 3650`)]);

export const insertPrivacySettingsSchema = createInsertSchema(privacySettingsTable);
export type InsertPrivacySettings = z.infer<typeof insertPrivacySettingsSchema>;
export type PrivacySettings = typeof privacySettingsTable.$inferSelect;
