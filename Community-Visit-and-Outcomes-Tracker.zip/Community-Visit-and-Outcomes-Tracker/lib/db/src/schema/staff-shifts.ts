import { pgTable, text, timestamp, uuid, index, uniqueIndex, check } from "drizzle-orm/pg-core";
import { sql } from "drizzle-orm";
import { createInsertSchema } from "drizzle-zod";
import { z } from "zod/v4";

export const staffShiftsTable = pgTable("staff_shifts", {
  id: uuid("id").defaultRandom().primaryKey(),
  ownerId: text("owner_id").notNull(),
  clockedInAt: timestamp("clocked_in_at", { withTimezone: true }).notNull().defaultNow(),
  clockedOutAt: timestamp("clocked_out_at", { withTimezone: true }),
}, (table) => [
  uniqueIndex("staff_shifts_one_open_per_owner").on(table.ownerId).where(sql`${table.clockedOutAt} IS NULL`),
  index("staff_shifts_owner_date_idx").on(table.ownerId, table.clockedInAt),
  check("staff_shifts_checkout_after_checkin", sql`${table.clockedOutAt} IS NULL OR ${table.clockedOutAt} >= ${table.clockedInAt}`),
]);

export const insertStaffShiftSchema = createInsertSchema(staffShiftsTable).omit({ id: true, clockedInAt: true });
export type InsertStaffShift = z.infer<typeof insertStaffShiftSchema>;
export type StaffShift = typeof staffShiftsTable.$inferSelect;
